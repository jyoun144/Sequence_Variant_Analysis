package sequenceVariant;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import sequenceVariant.FastqSequenceParser.Holder;
import utils.Constants;

public class countOneOffVariants
{

	public static HashMap<Holder, Integer> getNumberOfVariants(List<Holder> myList) throws Exception
	{

		HashMap<Holder, Integer> myMap = new HashMap<Holder, Integer>();
		List<Holder> copy = new ArrayList<>();
		copy.addAll(myList);

		for (Holder h : myList)
		{

			int numOfOneOffVariant = 0;

			for (Holder hCopy : myList)
			{

				FindMismatches ms = FindMismatches.getMismatches(hCopy, h);

				if (ms.getNum() == 1)
				{

					numOfOneOffVariant++;

				}

			}
			myMap.put(h, numOfOneOffVariant);

		}
		return myMap;
	}

	public static void writeTable(HashMap<Holder, Integer> myMap, String outDir) throws Exception
	{

		BufferedWriter wr = new BufferedWriter(new FileWriter(new File(outDir + File.separator + "NumVariants.txt")));

		wr.write("Seq\tAbundance\tnumVariant\n");

		for (Holder h : myMap.keySet())
		{

			int variants = myMap.get(h);

			wr.write(h.getSeq() + "\t" + h.getNum() + "\t" + variants + "\n");

		}

		wr.flush();
		wr.close();

	}

	public static void main(String[] args) throws Exception
	{

		String inputDir = args[0];
		String outputDir = args[1];
		
		Boolean reverse = false;
		
		FastqSequenceParser.parseAllFiles(inputDir, outputDir);

		List<String> files = PooledSamples.getAListOfParsedFiles(outputDir);

		HashMap<String, HashMap<String, Integer>> mapOfSamples = PooledSamples.readFiles(files, outputDir,reverse);

		List<Holder> listOfAllSequences = PooledSamples.totalAbundanceOfSVwithOrder(mapOfSamples);

		HashMap<Holder, Integer> numVariant = getNumberOfVariants(listOfAllSequences);

		writeTable(numVariant, outputDir);

	}

}
