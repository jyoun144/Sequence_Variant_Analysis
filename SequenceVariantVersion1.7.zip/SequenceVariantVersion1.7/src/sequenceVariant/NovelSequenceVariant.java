package sequenceVariant;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


/**
 * This programs determines number of novel sequence variants that are 
 * detected following adding new samples. This should be run after {@link sequenceVariant.RunPipelineForSelectedSamples}
 * 
 * @author Farnaz Fouladi
 *
 */

public class NovelSequenceVariant
{

	public static void main(String[] args) throws Exception
	{

		String path = args[0];
		String limit = args[1];
		Set<String> sv = new HashSet<String>();
		File outputDir = new File(path);
		String[] files = outputDir.list();
		HashMap<String, Integer> hm = new HashMap<>();

		List<String> listOfFiles = new ArrayList<>();

		for (String subDir : files)
		{
			if (subDir.startsWith("UniqueSVClusterOneMismatch"))
			{
				listOfFiles.add(subDir);
			}
		}

		Comparator<String> compareFileNames = new Comparator<String>()
		{
			public int compare(String sub1, String sub2)
			{
				return Double.compare(
						Integer.parseInt(sub1.substring(sub1.indexOf("_Samples") + 8, sub1.indexOf(".fasta"))),
						Integer.parseInt(sub2.substring(sub2.indexOf("_Samples") + 8, sub2.indexOf(".fasta"))));
			}
		};

		Collections.sort(listOfFiles, compareFileNames);

		for (String fileName : listOfFiles)
		{

			String numSample = fileName.substring(fileName.indexOf("_Samples") + 8, fileName.indexOf(".fasta"));

			if (Integer.parseInt(numSample) > Integer.parseInt(limit))
			{

				BufferedReader br = new BufferedReader(new FileReader(new File(path + File.separator + fileName)));

				Integer numSV_0 = sv.size();
				System.out.println("number of samples:" + numSample);
				System.out.println("number of SV0 is " + numSV_0);

				for (String nextLine = br.readLine(); nextLine != null; nextLine = br.readLine())
				{

					if (!nextLine.startsWith(">SV"))
					{

						sv.add(nextLine.substring(1, nextLine.length()));
					}

				}
				Integer numSV_1 = sv.size();
				Integer novelSV = numSV_1 - numSV_0;

				System.out.println("number of SV1 is " + numSV_1);
				System.out.println("number of novel SVs is " + novelSV);

				hm.put(numSample, novelSV);
				br.close();
			}

		}

		BufferedWriter wr = new BufferedWriter(new FileWriter(new File(path + File.separator + ".txt")));

		wr.write("NumOfSamples" + "\t" + "NumOfSV" + "\n");
		for (String numSample : hm.keySet())
		{
			wr.write(numSample + "\t" + hm.get(numSample) + "\n");
		}

		wr.close();

	}
}
