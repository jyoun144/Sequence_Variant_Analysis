package sequenceVariant;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import sequenceVariant.FastqSequenceParser.Holder;
import utils.Constants;

/**
 * This class generates a sequence variant table count.
 * 
 * @author Farnaz Fouladi
 *
 */

public class SequenceVariantTable
{

	/**
	 * This method revises the HashMap of samples based on the unique sequence
	 * variants that were remained after filtering
	 * {@link sequenceVariant.PooledSamples#getUniqueSequence}. All the sequences
	 * that survived the filtering will be kept and others are discarded from
	 * samples.
	 * 
	 * @param samples      a HashMap with samples as keys and HashMaps of unique
	 *                     sequences and their abundances as values returned by
	 *                     {@link sequenceVariant.PooledSamples#readFiles}.
	 * @param uniqueSVList unique sequence variants that are kept after filtering
	 * @return a list of two HashMaps- First element of the list : A HashMap with
	 *         samples as keys and HashMaps of unique sequences and their abundances
	 *         as values. These sequence variants were not present in the
	 *         uniqueSVList. They were removed during filtering. Second element of
	 *         the list: a new HashMap with samples as keys and HashMaps of unique
	 *         sequences and their abundances as values. These sequence variants
	 *         were present in the uniqueSVList.
	 * 
	 * 
	 * @throws Exception if an error occurs
	 */

	public static List<HashMap<String, HashMap<String, Integer>>> reviseSampleMap(
			HashMap<String, HashMap<String, Integer>> samples, List<Holder> uniqueSVList) throws Exception
	{

		List<HashMap<String, HashMap<String, Integer>>> myList = new ArrayList<>();

		HashMap<String, HashMap<String, Integer>> newSamples = new HashMap<String, HashMap<String, Integer>>();
		HashMap<String, HashMap<String, Integer>> oldSamples = new HashMap<String, HashMap<String, Integer>>();

		if (!uniqueSVList.isEmpty())
		{

			for (String sample : samples.keySet())
			{

				HashMap<String, Integer> sequencesInSample = samples.get(sample);

				HashMap<String, Integer> newSequencesInSample = new HashMap<String, Integer>();

				for (Holder sv : uniqueSVList)
				{

					String uniqueSV = sv.getSeq();

					if (sequencesInSample.containsKey(uniqueSV))
					{

						Integer countOfUniqueSV = sequencesInSample.get(uniqueSV);
						newSequencesInSample.put(uniqueSV, countOfUniqueSV);
						sequencesInSample.remove(uniqueSV);
					}
				}

				newSamples.put(sample, newSequencesInSample);
				oldSamples.put(sample, sequencesInSample);
			}

			myList.add(oldSamples);
			myList.add(newSamples);
		}
		return myList;
	}

	/**
	 * This method writes a sequence variant table with samples in rows and unique
	 * sequence variants in columns.
	 * 
	 * @param sampleMap a HashMap with samples as keys and HashMaps of unique
	 *                  sequences and their abundances as values.
	 * @param outputDir path to the main output directory.
	 * @throws IOException
	 */

	public static void writeTable(HashMap<String, HashMap<String, Integer>> sampleMap, String outputDir)
			throws IOException
	{
		List<Holder> finalAbundance = PooledSamples.totalAbundanceOfSVwithOrder(sampleMap);

		BufferedWriter writer = new BufferedWriter(
				new FileWriter(new File(outputDir + File.separator + Constants.TABLENAME)));

		writer.write("Samples" + "\t");

		for (int x = 0; x < finalAbundance.size(); x++)
		{
			if (x != finalAbundance.size() - 1)
				writer.write(finalAbundance.get(x).getSeq() + "\t");
			else
				writer.write(finalAbundance.get(x).getSeq() + "\n");
		}

		for (String sample : sampleMap.keySet())
		{
			writer.write(sample + "\t");

			HashMap<String, Integer> sequences = sampleMap.get(sample);

			for (int x = 0; x < finalAbundance.size(); x++)
			{
				Integer count = sequences.get(finalAbundance.get(x).getSeq());
				if (count == null)
					count = 0;

				if (x != finalAbundance.size() - 1)
					writer.write(count + "\t");
				else
					writer.write(count + "\n");
			}
		}

		writer.flush();
		writer.close();

	}

	/**
	 * This method writes all the sequences that did not pass the filtering
	 * threshold into a text file.
	 * 
	 * @param unClassifiedSV a HashMap that is the first element of the list
	 *                       returned by {@link #reviseSampleMap}
	 * @param outputDir      path to the main output directory
	 * @throws IOException
	 */

	public static void writeUnclassifiedTable(HashMap<String, HashMap<String, Integer>> unClassifiedSV,
			String outputDir) throws IOException
	{

		BufferedWriter writer = new BufferedWriter(
				new FileWriter(new File(outputDir + File.separator + Constants.NOTUNIQUESV)));

		List<Holder> totalSeq = PooledSamples.totalAbundanceOfSVwithOrder(unClassifiedSV);

		writer.write("Sequence" + "\t" + "Abundance" + "\n");

		for (Holder h : totalSeq)
			writer.write(h.getSeq() + "\t" + h.getNum() + "\n");

		writer.flush();
		writer.close();

	}

}
