package sequenceVariant;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;

import sequenceVariant.FastqSequenceParser.Holder;
import utils.MyLogger;


public class GetAllSequenceVariants
{

	
	public static List<String> getSequenceVariantsFromHashMap(HashMap<String,HashMap<String,Integer>> sampleMap,String outputDir) throws Exception{
		
		List<String> myList = new ArrayList<String>();
		
		for (String sample : sampleMap.keySet()) {
			
			HashMap<String,Integer> seqMap = sampleMap.get(sample);
			
			for (String seq : seqMap.keySet()) {
				
				if (! myList.contains(seq)) {
					myList.add(seq);
				}
			}
			
		}
		MyLogger.log(Level.INFO, "Unique Sequence Variants is "+myList.size(), outputDir);
		return myList;
		
	}
	
	public static void writeTable (HashMap<String,HashMap<String,Integer>> sampleMap, List<Holder> seqList,String fileName, String outputDir) throws Exception {
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File(outputDir + File.separator + fileName)));
		
		writer.write("SampleName"+"\t");
		
		for (int x = 0; x < seqList.size(); x++)
		{
			if (x != seqList.size() - 1)
				writer.write(seqList.get(x).getSeq() + "\t");
			else
				writer.write(seqList.get(x).getSeq() + "\n");
		}

		for (String sample : sampleMap.keySet())
		{
			writer.write(sample + "\t");

			HashMap<String, Integer> sequences = sampleMap.get(sample);

			for (int x = 0; x < seqList.size(); x++)
			{
				Integer count = sequences.get(seqList.get(x).getSeq());
				if (count == null)
					count = 0;

				if (x != seqList.size() - 1)
					writer.write(count + "\t");
				else
					writer.write(count + "\n");
			}
		}

		writer.flush();
		writer.close();
		
	}
	
	public static void main(String[] args) throws Exception
	{
		
		String inputDir = args[0];
		String outputDir = args[1];
		
		Boolean reverse = false;

		System.out.println("Input Directory is " + inputDir);
		System.out.println("Output Directory is " + outputDir);

		FastqSequenceParser.parseAllFiles(inputDir, outputDir);

		List<String> listOfFiles = PooledSamples.getAListOfParsedFiles(outputDir);
        HashMap<String, HashMap<String, Integer>> samples = PooledSamples.readFiles(listOfFiles, outputDir,reverse);
        List<Holder> seqList = PooledSamples.totalAbundanceOfSVwithOrder(samples); 
        MyLogger.log(Level.INFO, "Hasmap Is Constructed", outputDir);
        
        //List<String> seqList = getSequenceVariantsFromHashMap(samples,outputDir);
        
        MyLogger.log(Level.INFO, "UNIQUE SEQUENCE VARIANTS ARE IDENTIFIED", outputDir);
        MyLogger.log(Level.INFO, "Number of unique SVs are "+seqList.size(), outputDir);
        
        writeTable(samples,seqList,"AllPossibleSV.txt",outputDir);
	}
	
}
