package sequenceVariant;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;

import utils.Constants;

/**
 * This class parsers the {@value utils.Constants#SilvaMutationPercentage.txt}
 * 
 * @author Farnaz Fouladi
 *
 */
public class SilvaMutationPercentageParser
{
	private String A;
	private String C;
	private String G;
	private String T;
	private String N;
	private String gap;
	private String index;

	/**
	 * This constructor constructs SilvaMutationPercentageParser objects which are
	 * composed of percentage of A, C, G, T, and gap for each locus in the Silva
	 * alignment.
	 * 
	 * @param percentages this is one row of the
	 *                    {@value utils.Constants#SilvaMutationPercentage.txt}. Each
	 *                    row in the file corresponds to one index of a locus in
	 *                    Silva alignment.
	 */

	public SilvaMutationPercentageParser(String percentages)
	{

		String[] splits = percentages.split("\t");
		this.gap = splits[0];
		this.A = splits[2];
		this.C = splits[3];
		this.G = splits[4];
		this.N = splits[5];
		this.T = splits[6];
		this.index = splits[7];

	}

	public String getA()
	{
		return A;
	}

	public String getC()
	{
		return C;
	}

	public String getG()
	{
		return G;
	}

	public String getT()
	{
		return T;
	}

	public String getN()
	{
		return N;
	}

	public String getGap()
	{
		return gap;
	}

	public String getIndex()
	{
		return index;
	}

	/**
	 * This method parses the {@value utils.Constants#SilvaMutationPercentage.txt}.
	 * 
	 * @param input path to the file
	 *              {@value utils.Constants#SilvaMutationPercentage.txt}
	 * @return a HashMap where the keys are the indices of the Silva alignment and
	 *         the values are SilvaMutationPercentageParser objects composed of
	 *         percentages of A, G, C, T, N, and gaps for the corresponding indices.
	 * @throws Exception if the file
	 *                   {@value utils.Constants#SilvaMutationPercentage.txt} is not
	 *                   found or if it has duplicate indices.
	 */

	public static HashMap<String, SilvaMutationPercentageParser> readSilvaPermutationPercentage(String input)
			throws Exception
	{

		HashMap<String, SilvaMutationPercentageParser> myMap = new HashMap<String, SilvaMutationPercentageParser>();

		BufferedReader reader = new BufferedReader(new FileReader(new File(input)));

		for (String nextLine = reader.readLine(); nextLine != null; nextLine = reader.readLine())
		{

			if (!nextLine.startsWith("-"))
			{

				SilvaMutationPercentageParser myInstance = new SilvaMutationPercentageParser(nextLine);

				if (myMap.containsKey(myInstance.index))
				{

					reader.close();
					throw new Exception("Locus indices are not unique in the " + Constants.SILVAMUTATIONRATE);

				}
				myMap.put(myInstance.index, myInstance);

			}
		}
		reader.close();
		return myMap;

	}

}
