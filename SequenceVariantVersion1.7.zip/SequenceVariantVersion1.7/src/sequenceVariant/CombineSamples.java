package sequenceVariant;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import sequenceVariant.FastqSequenceParser.Holder;
import sequenceVariant.IndividualSamples.AbundancePermission;
import utils.Constants;
import utils.MyLogger;

/**
 * This program estimates a filtering threshold and infer unique sequence variants
 * for each individual samples and then generate a count table including all the sequence variants
 * from all samples.
 * 
 * @author farnazfouladi
 *
 */

public class CombineSamples
{
	/**
	 * This method forms clusters of one-off variants for each individual sample and
	 * returns a list of centroids of clusters from all the samples.
	 * 
	 * @param listOfSamples List of all samples
	 * @param outputDir     Path to output directory
	 * @return list of sequences that are the centroids of clusters
	 * @throws Exception
	 */

	public static List<String> getAllCentroids(List<String> listOfSamples, String outputDir) throws Exception
	{
		List<String> listOfCentroids = new ArrayList<>();

		for (String file : listOfSamples)
		{

			MyLogger.log(Level.INFO, "FileNames is " + file, outputDir);

			List<Holder> listOfSequences = IndividualSamples.parseOneFile(new File(file), outputDir);
			HashMap<Holder, List<FindMismatches>> cluster = IndividualSamples.findClusters(listOfSequences, outputDir);

			for (Holder h : cluster.keySet())
			{

				if (!listOfCentroids.contains(h.getSeq()))
					listOfCentroids.add(h.getSeq());

			}
		}
		return listOfCentroids;

	}
/**
 * This methods writes all the sequences from {@link #getAllCentroids} into a fasta file
 * @param listOfCentroids The output from {@link #getAllCentroids}
 * @param fileName Name of the fasta file to be written 
 * @param outputDir Path to output directory 
 * @throws Exception
 */
	
	public static void writeCentroids(List<String> listOfCentroids, String fileName, String outputDir) throws Exception
	{

		BufferedWriter writer = new BufferedWriter(new FileWriter(new File(outputDir + File.separator + fileName)));

		int numCentroid = 0;
		for (String seq : listOfCentroids)
		{
			numCentroid++;
			writer.write(">centroid" + numCentroid + "\n" + seq + "\n");
		}
		writer.flush();
		writer.close();

	}

	/**
	 * This method does followings for each individual sample:
	 * <ol>
	 * <li> Forms clusters of one-off variants
	 * <li> Determines the fraction of sequence variants with more than a specified allele frequency at different abundance thresholds
	 * <li> Finds an abundance threshold based on the user selected fraction of sequence variants with more than a specified allele frequency
	 * <Li> Filters sequences based on the filtering threshold
	 * <Li> Collects all the unique sequences from all samples into a list </lo>
	 * 
	 * @param indexMap a HashMap with centroid sequences as keys and HashMaps of
	 *                 centroid indices and the corresponding Silva alignment indices as
	 *                 values returned by {@link sequenceVariant.IndividualSamples#getIndexforAlignmentandRead}.
	 * @param listOfSamples List of all samples 
	 * @param selectedUserRatio User selected fraction of sequence variants with more than a specified allele frequency
	 * @param outputDir Path to output directory
	 * @return
	 * @throws Exception
	 */
	public static List<String> getUniqueSequence(HashMap<String, HashMap<Integer, Integer>> indexMap,
			List<String> listOfSamples, String selectedUserRatio, String outputDir) throws Exception
	{

		List<String> listOfAllUniqueSeq = new ArrayList<>();

		for (String file : listOfSamples)
		{

			String fileName = file.substring(0, file.indexOf(".txt"));
			List<Holder> listOfSequences = IndividualSamples.parseOneFile(new File(file), outputDir);
			HashMap<Holder, List<FindMismatches>> cluster = IndividualSamples.findClusters(listOfSequences, outputDir);
			HashMap<Holder, List<FindMismatches>> newCluster = IndividualSamples.getSilvaIndexForMismatches(cluster,
					indexMap);

			IndividualSamples.writeClusterTable(newCluster, fileName + "_table.txt", outputDir);

			List<Integer> abundances = IndividualSamples.getAbundancesOfMismatches(newCluster);

			List<Double> permission = IndividualSamples.getPermissionsOfMismatches(newCluster);

			List<AbundancePermission> apTrue = IndividualSamples.getListOfAbundancePermission(abundances, permission);


			List<Double> thresholds = IndividualSamples.getARange(Constants.MINRANGE,
					Math.log10(Double.valueOf(apTrue.get(apTrue.size() - 1).getAbundance())),
					Constants.INTERVALFORRANGE);

			List<Double> redToTotalRatio = IndividualSamples.getRedToTotalRatio(apTrue, thresholds);

			Double t = PooledSamples.getThreshold(redToTotalRatio, Double.valueOf(selectedUserRatio), thresholds,
					outputDir);

			IndividualSamples.writeRatios(redToTotalRatio, thresholds, fileName + "_Ratio.txt", outputDir);

			MyLogger.log(Level.INFO, "Threshold is" + t, outputDir);

			List<Holder> UniqueSequencesinCluster = IndividualSamples.getUniqueSequence(newCluster, t, outputDir);

			for (Holder h : UniqueSequencesinCluster)
			{
				if (!listOfAllUniqueSeq.contains(h.getSeq()))
				{
					listOfAllUniqueSeq.add(h.getSeq());
				}
			}
		}

		MyLogger.log(Level.INFO, "***Total number of unique sequences in the table is " + listOfAllUniqueSeq.size(),
				outputDir);
		return listOfAllUniqueSeq;

	}
	/**
	 * This method generates a count table.
	 * @param mapOfAllSamples A hashmap including samples as keys and hashmaps of the sequences (key)
	 * and their abundances (values) as values
	 * @param listOfAllUniqueSeq The list generated from {@link#getUniqueSequence}
	 * @param outputDir Path to the output Directory 
	 * @throws Exception
	 */

	public static void writeTable(HashMap<String, HashMap<String, Integer>> mapOfAllSamples,
			List<String> listOfAllUniqueSeq, String outputDir) throws Exception
	{

		BufferedWriter writer = new BufferedWriter(
				new FileWriter(new File(outputDir + File.separator + "SVTable_IndividualSamples.txt")));

		writer.write("Samples" + "\t");

		for (int x = 0; x < listOfAllUniqueSeq.size(); x++)
		{
			if (x != listOfAllUniqueSeq.size() - 1)
				writer.write(listOfAllUniqueSeq.get(x) + "\t");
			else
				writer.write(listOfAllUniqueSeq.get(x) + "\n");
		}

		for (String sample : mapOfAllSamples.keySet())
		{
			writer.write(sample + "\t");

			HashMap<String, Integer> sequences = mapOfAllSamples.get(sample);

			for (int x = 0; x < listOfAllUniqueSeq.size(); x++)
			{
				Integer count = sequences.get(listOfAllUniqueSeq.get(x));
				if (count == null)
					count = 0;

				if (x != listOfAllUniqueSeq.size() - 1)
					writer.write(count + "\t");
				else
					writer.write(count + "\n");
			}
		}

		writer.flush();
		writer.close();
	}

	
	public static void main(String[] args) throws Exception
	{
		String inputDir = args[0];
		String outputDir = args[1];
		String selectedThreshold = args[2];
		
		String reverseReads = null;
		
		if (args.length==4) reverseReads = args [3];
		
		Boolean reverse = false;
		
		if (reverseReads!=null & reverseReads.equals("reverse")) reverse = true;
		

		System.out.println("Input Directory is " + inputDir);
		System.out.println("Output Directory is " + outputDir);

		FastqSequenceParser.parseAllFiles(inputDir, outputDir);
		List<String> listOfFiles = PooledSamples.getAListOfParsedFiles(outputDir);
		HashMap<String, HashMap<String, Integer>> samples = PooledSamples.readFiles(listOfFiles, outputDir,reverse);

		File parsedFileDirectory = new File(outputDir + File.separator + Constants.PARSEDFILES);
		String[] listOfParsedFiles = parsedFileDirectory.list();
		List<String> allFiles = Arrays.asList(listOfParsedFiles);
		List<String> listOfCentroids = getAllCentroids(allFiles, outputDir);
		writeCentroids(listOfCentroids, "AllCentroids_Samples.fasta", outputDir);
		IndividualSamples.runMother("AllCentroids_Samples.fasta", outputDir);
		HashMap<String, HashMap<Integer, Integer>> indexMap = IndividualSamples
				.getIndexforAlignmentandRead("AllCentroids_Samples.fasta", outputDir);
		List<String> listOfAllUniqueSeq = getUniqueSequence(indexMap, allFiles, selectedThreshold, outputDir);
		writeTable(samples, listOfAllUniqueSeq, outputDir);

	}

}
