package sequenceVariant;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.StringTokenizer;

import sequenceVariant.FastqSequenceParser.Holder;
import utils.ConfigReader;
import utils.Constants;

public class Parent
{

	// the keys are the name of parent and the value is the template ID
	public static HashMap<String, String> getMapOfIDs(HashMap<String, MothurParser> map)
	{

		HashMap<String, String> mapOfIDs = new HashMap<>();

		for (String query : map.keySet())
		{

			mapOfIDs.put(map.get(query).getQuery(), map.get(query).getSubject());

		}
		return mapOfIDs;

	}

	// List of template IDs
	public static List<String> getListOfIDs(HashMap<String, MothurParser> map)
	{

		List<String> listOfIDs = new ArrayList<>();

		for (String query : map.keySet())
		{

			listOfIDs.add(map.get(query).getSubject());

		}
		return listOfIDs;

	}

	public static void writeAlignmentsFromSilva(List<String> silvaIDs, String outputDir, String FileName)
			throws Exception
	{

		String silvaPath = ConfigReader.getSilvaAlignmentDir() + File.separator + Constants.SILVAALIGNMENT;

		BufferedReader reader = new BufferedReader(new FileReader(new File(silvaPath)));
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File(outputDir + File.separator + FileName)));

		for (String nextLine = reader.readLine(); nextLine != null; nextLine = reader.readLine())
		{

			if (nextLine.startsWith(">"))
			{

				String id = nextLine.substring(1, nextLine.indexOf("\t"));

				if (silvaIDs.contains(id))
				{

					writer.write(">" + id + "\n");

					String alignment = reader.readLine();
					writer.write(alignment + "\n");

				}

			}
		}

		reader.close();
		writer.flush();
		writer.close();
	}

	public static HashMap<String, String> getSilvaAlignmentMap(String fileName, String outputDir) throws Exception
	{
		String filePath = outputDir + File.separator + fileName;

		HashMap<String, String> map = new HashMap<String, String>();
		try (BufferedReader reader = new BufferedReader(new FileReader(new File(filePath))))
		{
			for (String slivaHeaderLine = reader.readLine(); slivaHeaderLine != null; slivaHeaderLine = reader
					.readLine())
			{
				String silvaAlignment = reader.readLine();
				map.put(slivaHeaderLine.substring(1, slivaHeaderLine.length()), silvaAlignment);

			}
		}

		return map;

	}

	public static HashMap<String, ParentMismatches> mapAlignmentFilesAndFindMismatches(String alignmentReportFilePath,
			String centroidAlignmentPath, HashMap<String, String> silvaMap, HashMap<String, Holder> centroidAbundance,
			HashMap<String, SilvaMutationPercentageParser> silvaAlleleFrequence, String outputDir) throws Exception
	{
		int counter = 1;

		HashMap<String, ParentMismatches> mismatches = new HashMap<>();

		try (BufferedReader alignmentReportReader = new BufferedReader(
				new FileReader(new File(outputDir + File.separator + alignmentReportFilePath))))
		{
			try (BufferedReader centrioidAlignmentReader = new BufferedReader(
					new FileReader(new File(outputDir + File.separator + centroidAlignmentPath))))
			{
				for (String alignmentReportLine = alignmentReportReader
						.readLine(); alignmentReportLine != null; alignmentReportLine = alignmentReportReader
								.readLine())
				{

					String centroidHeaderLine = centrioidAlignmentReader.readLine();
					if (centroidHeaderLine != null)
					{
						if (alignmentReportLine.startsWith("QueryName"))
						{
							alignmentReportLine = alignmentReportReader.readLine();
						}
						MothurParser mp = new MothurParser(alignmentReportLine);

						String centroidAlignmentHeader = centroidHeaderLine.substring(1, centroidHeaderLine.length());
						String centroidAlignment = centrioidAlignmentReader.readLine();
						String silvaAlignmentTemplateHeader = mp.getSubject();
						String silvaAlignmentTemplate = silvaMap.get(silvaAlignmentTemplateHeader);
						String centroidSequence = centroidAbundance.get(centroidAlignmentHeader).getSeq();
						Integer centroidAbundace = centroidAbundance.get(centroidAlignmentHeader).getNum();

						ParentMismatches pms = ParentMismatches.getMismatches(silvaAlignmentTemplateHeader,
								silvaAlignmentTemplate, centroidAlignmentHeader, centroidAlignment, centroidAbundace,
								silvaAlleleFrequence);

						mismatches.put(centroidSequence, pms);

					}

					counter++;
				}
			}
		}

		return mismatches;
	}

	public static HashMap<String, Holder> getCentroidAbundance(String outputDir) throws Exception
	{

		HashMap<String, Holder> mapAbundance = new HashMap<>();

		BufferedReader reader = new BufferedReader(
				new FileReader(new File(outputDir + File.separator + "CentroidAbundance.txt")));

		for (String nextLine = reader.readLine(); nextLine != null; nextLine = reader.readLine())
		{

			if (!nextLine.startsWith("Name"))
			{

				StringTokenizer line = new StringTokenizer(nextLine, "\t");

				String centroidName = line.nextToken();
				String centroidSeq = line.nextToken();
				Integer centroidAbundance = Integer.parseInt(line.nextToken());
				Holder h = new Holder(centroidSeq, centroidAbundance);

				mapAbundance.put(centroidName, h);

			}

		}
		reader.close();
		return mapAbundance;

	}

	public static void writeParentMismatches(HashMap<String, ParentMismatches> mismatches, String outputDir,
			String fileName) throws Exception
	{

		BufferedWriter writer = new BufferedWriter(new FileWriter(new File(outputDir + File.separator + fileName)));

		writer.write("Parent" + "\t" + "NumMismatch" + "\t" + "SubjectSNP" + "\t" + "QuerySNP" + "\t" + "Abundance"
				+ "\t" + "Index" + "\t" + "Permessive" + "\n");

		for (String centroid : mismatches.keySet())
		{

			ParentMismatches ms = mismatches.get(centroid);

			if (ms.getNum() == 1)
				writer.write(centroid + "\t" + ms.getNum() + "\t" + ms.getsnpS().get(0) + "\t" + ms.getsnpQ().get(0)
						+ "\t" + ms.getAbundance() + "\t" + ms.getIndex().get(0) + "\t"
						+ ms.getPermessivePercentage().get(0) + "\n");

			else if (ms.getNum() > 1)
				writer.write(centroid + "\t" + ms.getNum() + "\t" + "NA" + "\t" + "NA" + "\t" + ms.getAbundance() + "\t"
						+ "NA" + "\t" + 0 + "\n");

			else if (ms.getNum() == 0)
				writer.write(centroid + "\t" + 0 + "\t" + "NA" + "\t" + "NA" + "\t" + ms.getAbundance() + "\t" + "NA"
						+ "\t" + 100 + "\n");

		}

		writer.flush();
		writer.close();

	}

	public static LinkedHashMap<ParentMismatches, List<FindMismatches>> replaceCentroidsWithParentMismatches(
			LinkedHashMap<Holder, List<FindMismatches>> cluster, HashMap<String, ParentMismatches> parents)
	{

		LinkedHashMap<ParentMismatches, List<FindMismatches>> newMap = new LinkedHashMap<>();

		for (Holder centroid : cluster.keySet())
		{

			List<FindMismatches> oneOffVariants = cluster.get(centroid);

			ParentMismatches parent = parents.get(centroid.getSeq());

			newMap.put(parent, oneOffVariants);
		}
		return newMap;

	}

}
