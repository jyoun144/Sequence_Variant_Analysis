package sequenceVariant;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.logging.Level;

import sequenceVariant.FastqSequenceParser.Holder;
import sequenceVariant.PooledSamples.AbundanceAlleleFreq;
import sequenceVariant.PooledSamples.Holder1;
import utils.ConfigReader;
import utils.Constants;
import utils.MyLogger;

public class RunPipeline
{
	/**
	 * This is the main method and runs the following programs:
	 * <ol>
	 * <li>{@link sequenceVariant.FastqSequenceParser}
	 * <li>{@link sequenceVariant.PooledSamples}
	 * <li>{@link sequenceVariant.SequenceVariantTable}
	 * </ol>
	 * 
	 * @param args input directory, output directory
	 * @throws Exception if an error occurs
	 */

	public static void main(String[] args) throws Exception
	{

		String inputDir = args[0];
		String outputDir = args[1];
		String selectedUserRatio = args[2];
		String alleleFrequency = args[3];

		String reverseReads = null;

		if (args.length == 5)
			reverseReads = args[4];

		Boolean reverse = false;

		if (reverseReads != null && reverseReads.equals("reverse"))
			reverse = true;

		System.out.println("Input Directory is " + inputDir);
		System.out.println("Output Directory is " + outputDir);

		FastqSequenceParser.parseAllFiles(inputDir, outputDir);

		MyLogger.log(Level.INFO,
				"Input Directory is " + inputDir + "\nOutput Directory is " + outputDir
						+ "\nFraction of sequence variants with allele frequency more than " + alleleFrequency + " is "
						+ selectedUserRatio,
				outputDir);

		List<String> listOfFiles = PooledSamples.getAListOfParsedFiles(outputDir);

		HashMap<String, HashMap<String, Integer>> samples = PooledSamples.readFiles(listOfFiles, outputDir, reverse);

		List<Holder> allSeq = PooledSamples.totalAbundanceOfSVwithOrder(samples);

		LinkedHashMap<String, Holder1> mapOfSequences = PooledSamples.convertListToLinkedHashMap(allSeq);

		LinkedHashMap<Holder, List<FindMismatches>> cluster1 = PooledSamples.findCluster(mapOfSequences, outputDir);
		PooledSamples.writeCentroids(cluster1, Constants.ONEMISMATCHCENTROIDSFILENAME, outputDir);

		PooledSamples.writeCluster(cluster1, outputDir);

		Boolean cluster1Exists = PooledSamples.doesClusterExist(cluster1);

		PooledSamples.runMother(cluster1Exists, Constants.ONEMISMATCHCENTROIDSFILENAME, outputDir);

		HashMap<String, String> mapOfSeq = FastaSequenceParser
				.readFastaFileAndGetMap(outputDir + File.separator + Constants.ONEMISMATCHCENTROIDSFILENAME);

		LinkedHashMap<String, HashMap<Integer, Integer>> indexForCluster1 = PooledSamples.getIndexforAlignmentandRead(
				Constants.ONEMISMATCHCENTROIDSFILENAME, Constants.ONEMISMATCHCENTROIDALIGNMENTFILENAME, mapOfSeq,
				cluster1Exists, outputDir);

		PooledSamples.writeIndexMap(indexForCluster1, outputDir);

		LinkedHashMap<Holder, List<FindMismatches>> newCluster1 = PooledSamples.getSilvaIndexForMismatches(cluster1,
				indexForCluster1);

		MyLogger.log(Level.INFO, "Size of the indexMap is " + indexForCluster1.size()
				+ "\nSize of the cluster map after incorporating indeces is " + newCluster1.size(), outputDir);

		PooledSamples.writeClusterTable(newCluster1, Constants.ONEMISMATCHCLUSTERTABLE, outputDir);

		// Parents

		// Find alignments from the SILVA database and write them into a new file
		// (SelectedSilvaAlignments.fasta)
		HashMap<String, MothurParser> mothurParer = MothurParser.reportParser(outputDir);
		List<String> templateIDs = Parent.getListOfIDs(mothurParer);
		Parent.writeAlignmentsFromSilva(templateIDs, outputDir, "SelectedSilvaAlignments.fasta");

		// Parse CentroidAbundance.txt
		HashMap<String, Holder> centroidAbundance = Parent.getCentroidAbundance(outputDir);

		MyLogger.log(Level.INFO, "number of Silva alignments is " + templateIDs.size() + "\nnumber of parents is "
				+ centroidAbundance.size(), outputDir);

		HashMap<String, String> selectedSilvaMap = Parent.getSilvaAlignmentMap("SelectedSilvaAlignments.fasta",
				outputDir);

		// Parse allele frequency file
		HashMap<String, SilvaMutationPercentageParser> silvaAlleleFrequencies = SilvaMutationPercentageParser
				.readSilvaPermutationPercentage(
						ConfigReader.getSilvaMutationRateDir() + File.separator + Constants.SILVAMUTATIONRATE);

		HashMap<String, ParentMismatches> parents = Parent.mapAlignmentFilesAndFindMismatches(Constants.MOTHURREPORT,
				Constants.ONEMISMATCHCENTROIDALIGNMENTFILENAME, selectedSilvaMap, centroidAbundance,
				silvaAlleleFrequencies, outputDir);

		MyLogger.log(Level.INFO, "Size of the hashmap of the parentmismatches is " + parents.size(), outputDir);

		Parent.writeParentMismatches(parents, outputDir, "parents.txt");

		// Adding parents mismtches to the cluster

		LinkedHashMap<ParentMismatches, List<FindMismatches>> clusterWithParents = Parent
				.replaceCentroidsWithParentMismatches(newCluster1, parents);

		List<AbundanceAlleleFreq> abunFreq = PooledSamples.getListOfAbundanceAlleleFreqFromCluster(clusterWithParents);

		MyLogger.log(Level.INFO, "Size of the list of AbundanceAlleleFreq  " + abunFreq.size(), outputDir);

		List<Double> thresholds = PooledSamples.getARange(Constants.MINRANGE,
				Math.log10(Double.valueOf(abunFreq.get(abunFreq.size() - 1).getAbundance())),
				Constants.INTERVALFORRANGE);

		List<Double> alleleFreqFractio = PooledSamples.getAlleleFreqFraction(abunFreq, thresholds,
				Double.parseDouble(alleleFrequency));

		List<Integer> numSVList = PooledSamples.getNumSVForEachThreshold(abunFreq, thresholds);

		PooledSamples.writeRatios(alleleFreqFractio, numSVList, thresholds, outputDir);

		Double t = PooledSamples.getThreshold(alleleFreqFractio, Double.valueOf(selectedUserRatio), thresholds,
				outputDir);

		List<Holder> UniqueSequencesinCluster1 = PooledSamples.getUniqueSequence(newCluster1, t,
				Double.parseDouble(alleleFrequency), outputDir);

		PooledSamples.writeUniqueSV(UniqueSequencesinCluster1, Constants.UNIQUESVCLUSTERONEMISMATCH, outputDir);

		List<HashMap<String, HashMap<String, Integer>>> sampleMapwithCluster1 = SequenceVariantTable
				.reviseSampleMap(samples, UniqueSequencesinCluster1);

		HashMap<String, HashMap<String, Integer>> finalMap = sampleMapwithCluster1.get(1);

		SequenceVariantTable.writeUnclassifiedTable(sampleMapwithCluster1.get(0), outputDir);

		SequenceVariantTable.writeTable(finalMap, outputDir);

	}
}
