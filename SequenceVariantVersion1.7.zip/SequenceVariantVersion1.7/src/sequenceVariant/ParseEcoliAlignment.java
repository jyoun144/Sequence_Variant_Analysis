package sequenceVariant;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;


public class ParseEcoliAlignment
{
	
	private char base;
	private int index;
	
	public ParseEcoliAlignment (int index, char base) {
		
		this.base = base;
		this.index = index;
	}
	
	public char getBase() {
		return this.base;
	}
	
	public int getIndex() {
		return this.index;
	}
	
	
	
	public static HashMap <Integer,ParseEcoliAlignment> getIndex (String alingment){
		
		
		HashMap<Integer,ParseEcoliAlignment> myMap = new HashMap<Integer,ParseEcoliAlignment>();
		int baseNum=0;
		
		for (int x =0; x< alingment.length(); x++ ) {
			
			char character =alingment.charAt(x);
			
			if (character =='A' | character== 'C' | character=='G' | character=='T') {
				baseNum++;
				myMap.put(x, new ParseEcoliAlignment (baseNum,character));	
			}
				
			else {
				
				
				myMap.put(x, new ParseEcoliAlignment (0,character));
				
			}
		}
		return myMap;
	}
	
	public static void writeTable (HashMap <Integer,ParseEcoliAlignment> myMap,String fileName,String outputDir) throws IOException {
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File(outputDir+File.separator+fileName)));
		
		
		writer.write("Silva Index\tEcoli Index\tEcoli Base\n");
		
		
		for (Integer silvaIndex: myMap.keySet()) {
			
			writer.write(silvaIndex + "\t"+ myMap.get(silvaIndex).getIndex() + "\t" + myMap.get(silvaIndex).getBase() + "\n");
			
		}
		writer.close();
		
	}
	
	public static void main(String[] args) throws Exception
	{
		String inputPath = args [0];
		String outputDir = args [1];
		
		List<AlignmentParser> listOfAlignment = AlignmentParser.getListOfAlignment(inputPath);
		
		HashMap <Integer,ParseEcoliAlignment> myMap =getIndex(listOfAlignment.get(0).getAlignment());
		
		writeTable(myMap,"EcoliAlignmentNoGap.txt",outputDir);
		
		
	}

}
