package sequenceVariant;

import java.util.ArrayList;
import java.util.List;

import sequenceVariant.FastqSequenceParser.Holder;

/**
 * This class is composed of subject
 * sequence, query sequence, list of mismatch indices, number of mismatches,
 * list of mismatches in the subject, list of mismatches in the query, query
 * abundance, ratio of query abundance to subject abundance, list of
 * corresponding mismatch indices in the Silva database, list of percentages of
 * permessiveness for the mismatches (rate of mismatches observed in the
 * database). FindMismatches are equal if they have the same query.
 * 
 * @author Farnaz Fouladi
 *
 */

public class FindMismatches
{

	private String subject;
	private String query;
	private List<Integer> index;
	private Integer num;
	private List<Character> snpQ;
	private List<Character> snpS;
	private Integer abundance;
	private List<Integer> indexSliva;
	private List<String> permessivePercentage;

	/**
	 * A FindMismatches object is constructed using the following parameters:
	 * 
	 * @param subject   subject sequence
	 * @param query     query sequence
	 * @param index     list of indices for mismatches
	 * @param num       number of mismatches
	 * @param snpQ      list of mismatched bases in the query sequence
	 * @param snpS      list of mismatched bases in the subject sequence
	 * @param abundance query abundance
	 * @param ratio     ratio of query abundance to subject abundance
	 */

	public FindMismatches(String subject, String query, List<Integer> index, Integer num, List<Character> snpQ,
			List<Character> snpS, Integer abundance)
	{
		this.subject = subject;
		this.query = query;
		this.index = index;
		this.num = num;
		this.snpQ = snpQ;
		this.snpS = snpS;
		this.abundance = abundance;
	}

	/**
	 * A FindMismatches object is constructed using the following parameters:
	 * 
	 * @param subject              subject sequence
	 * @param query                query sequence
	 * @param index                list of indices for mismatches
	 * @param num                  number of mismatches
	 * @param snpQ                 list of mismatched bases in the query sequence
	 * @param snpS                 list of mismatched bases in the subject sequence
	 * @param abundance            query abundance
	 * @param ratio                ratio of query abundance to subject abundance
	 * @param indexSilva           list of indices of Silva alignment at mismatched
	 *                             loci
	 * @param permessivePercentage list of percentages of observed mismatches in the
	 *                             Silva database
	 */

	public FindMismatches(String subject, String query, List<Integer> index, Integer num, List<Character> snpQ,
			List<Character> snpS, Integer abundance, List<Integer> indexSilva,
			List<String> permessivePercentage)
	{
		this.subject = subject;
		this.query = query;
		this.index = index;
		this.num = num;
		this.snpQ = snpQ;
		this.snpS = snpS;
		this.abundance = abundance;
		this.indexSliva = indexSilva;
		this.permessivePercentage = permessivePercentage;
	}

	public String getSubject()
	{
		return subject;
	}

	public String getQuery()
	{
		return query;
	}

	public List<Integer> getIndex()
	{
		return index;
	}

	public Integer getNum()
	{
		return num;
	}

	public List<Character> getsnpQ()
	{
		return snpQ;
	}

	public List<Character> getsnpS()
	{
		return snpS;
	}

	public Integer getAbundance()
	{
		return abundance;
	}

	public List<Integer> getIndexSilva()
	{
		return indexSliva;
	}

	public List<String> getPermessivePercentage()
	{
		return permessivePercentage;
	}

	@Override
	public boolean equals(Object obj)
	{

		FindMismatches other = (FindMismatches) obj;

		return other.getQuery().equals(this.getQuery());
	}

	@Override
	public int hashCode()
	{

		return query.hashCode();
	}

	/**
	 * This method compares subject and query sequences and creates a FindMismatches
	 * object.
	 * 
	 * @param subject a Holder containing a subject sequence and its abundance.
	 * @param query   a Holder containing a query sequence and its abundance.
	 * @see sequenceVariant.FastqSequenceParser.Holder
	 * @return FindMismatches object
	 * @throws Exception if query and subject do not have the same length.
	 */

	public static FindMismatches getMismatches(Holder subject, Holder query) throws Exception
	{

		Integer abundanceOfSubject = subject.getNum();
		Integer abundanceOfQuery = query.getNum();
		Double ratio = (double) abundanceOfQuery / (double) abundanceOfSubject;

		String sequenceOfSubject = subject.getSeq();
		String sequenceOfQuery = query.getSeq();

		if (sequenceOfSubject.length() != sequenceOfQuery.length())
		{
			throw new Exception("Sequence lengths for subject and query are not identical");
		}

		int mismatch = 0;

		List<Integer> index = new ArrayList<Integer>();

		List<Character> snpS = new ArrayList<Character>();

		List<Character> snpQ = new ArrayList<Character>();

		for (int x = 0; x < sequenceOfSubject.length(); x++)
		{

			if (sequenceOfSubject.charAt(x) != 'N' && sequenceOfQuery.charAt(x) != 'N'
					&& sequenceOfSubject.charAt(x) != sequenceOfQuery.charAt(x))
			{

				index.add(x);
				mismatch++;
				snpS.add(sequenceOfSubject.charAt(x));
				snpQ.add(sequenceOfQuery.charAt(x));
			}

		}
		return new FindMismatches(sequenceOfSubject, sequenceOfQuery, index, mismatch, snpQ, snpS, abundanceOfQuery);
	}

}
