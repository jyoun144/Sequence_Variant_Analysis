package sequenceVariant;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.logging.Level;

import sequenceVariant.FastqSequenceParser.Holder;
import utils.ConfigReader;
import utils.Constants;
import utils.MyLogger;
import utils.ProcessWrapper;

public class IndividualSamples
{

	
	public static List <Holder> parseOneFile (File file, String outputDir) throws Exception{
		
		List <Holder> myList = new ArrayList<>();
		
		BufferedReader reader = new BufferedReader(new FileReader(outputDir+File.separator+Constants.PARSEDFILES+File.separator+file));
		
		for (String nextline = reader.readLine(); nextline != null; nextline = reader.readLine()) {
			
			if (!nextline.startsWith("Sequence")) {
				
				String seq = nextline.substring(0, nextline.indexOf("\t"));
				String numSeq = nextline.substring(nextline.indexOf("\t") + 1, nextline.length());
				Integer abundanceOfSeq = Integer.parseInt(numSeq);
				
				if (!numSeq.equals("1")) {
					
					myList.add(new Holder (seq, abundanceOfSeq));
				}

			}
				
		}
		reader.close();
        return myList;
		
	}
	
	public static long getTotalAbundance(List<Holder> listofSeuences,String outputDir) throws Exception
	{
		long abundance = 0;
		for (Holder h : listofSeuences)
		{
			abundance = abundance + h.getNum();
		}

		MyLogger.log(Level.INFO, "Total abundance after removing singletons:" + abundance,outputDir);
		return abundance;
	}

	
	public static List<Double> getRelativeAbundance(List<Holder> listofSeuences,String outputDir) throws Exception
	{

		long totalAbundance = getTotalAbundance(listofSeuences,outputDir);
		List<Double> relativeAbundaces = new ArrayList<>();

		for (Holder h : listofSeuences)
		{
			relativeAbundaces.add(((double) h.getNum() / (double) totalAbundance));
		}

		return relativeAbundaces;
	}
	
	
	public static HashMap<Holder, List<FindMismatches>> findClusters(List<Holder> listOfSequences,String outputDir) throws Exception
	
		
	{
		List<Double> relativeAbundances = getRelativeAbundance(listOfSequences,outputDir);
		HashMap<Holder, List<FindMismatches>> mapOfclusters = new HashMap<Holder, List<FindMismatches>>();
	    Set<String> oneMismatchMember = new HashSet<String>();
		Set<String> oneMismatchCentroid = new HashSet<String>();
		
		for (int x = 0; x < listOfSequences.size(); x++)
		{

			String s1 = listOfSequences.get(x).getSeq();

			if (relativeAbundances.get(x) > utils.Constants.RELATIVEABUNDANCETHRESHOLD && !oneMismatchMember.contains(s1)
					&& !oneMismatchCentroid.contains(s1))
			{

				List<FindMismatches> oneMistmatchList = new ArrayList<FindMismatches>();

				for (int y = x + 1; y < listOfSequences.size(); y++)
				{

					String s2 = listOfSequences.get(y).getSeq();

					if (!oneMismatchMember.contains(s2) && !oneMismatchCentroid.contains(s2))
					{

						FindMismatches mismatches = FindMismatches.getMismatches(listOfSequences.get(x),
								listOfSequences.get(y));

						if (mismatches.getNum() == 1)
						{
							oneMistmatchList.add(mismatches);
							oneMismatchMember.add(s2);

						}

					}
				}

				if (oneMistmatchList.size() != 0)
				{

					mapOfclusters.put(listOfSequences.get(x), oneMistmatchList);
					oneMismatchCentroid.add(s1);

				}
			}
		}

		MyLogger.log(Level.INFO, "Number of total members for cluster: " + oneMismatchMember.size(),outputDir);
		MyLogger.log(Level.INFO, "Number of total centroids for cluster: " + oneMismatchCentroid.size(),outputDir);

		return mapOfclusters;
	}
	
	public static void writeCentroids(HashMap<Holder, List<FindMismatches>> mapOfCluster,String FileName,String outputDir) throws Exception, Exception
	{

		
			BufferedWriter writer = new BufferedWriter(new FileWriter(
					new File(outputDir + File.separator + FileName)));

			int numCentroid = 0;
			for (Holder h : mapOfCluster.keySet())
			{
				numCentroid++;
				writer.write(">centroid" + numCentroid + "\n" + h.getSeq() + "\n");
			}
			writer.flush();
			writer.close();
	}

	
	public static void runMother(String FileName,String outputDir) throws Exception
	{

		File filePath = new File(outputDir + File.separator + FileName);


			String[] a = new String[2];
			a[0] = ConfigReader.getMothurDir() + File.separator + "mothur";
			a[1] = "#set.dir(output=" + outputDir + ");" + "align.seqs(candidate="
					+ filePath.getAbsolutePath() + ", template=" + ConfigReader.getSilvaAlignmentDir() + File.separator
					+ Constants.SILVAALIGNMENT + ")";
			ProcessWrapper p = new ProcessWrapper(a);
		
	}
	
	public static List<String> flipFileParser(String FileName,String outputDir) throws Exception
	{

		StringTokenizer str = new StringTokenizer(FileName, ".");
		String flipFile = str.nextToken() + ".flip.accnos";
		
		List<String> seqWithNoAlignment = new ArrayList<String>();

		File outputDirectory = new File(outputDir);
		String[] files = outputDirectory.list();
		for (String file : files)
		{
			if (file.endsWith(flipFile))
			{
				seqWithNoAlignment = AlignmentParser
						.getSeqwithNoAlignment(outputDir + File.separator + file);

			}
		}
		
		MyLogger.log(Level.INFO, "Number of centroids that did not produce alignments: " + seqWithNoAlignment.size()
		+ " Check " + flipFile, outputDir);
		
		return seqWithNoAlignment;
	}
	
	
	public static HashMap<String, HashMap<Integer, Integer>> getIndexforAlignmentandRead(
			String FileName,String outputDir) throws Exception
	{
	
		StringTokenizer str = new StringTokenizer(FileName, ".");
		String alignmentFile = str.nextToken() + ".align";
		
		HashMap<String, HashMap<Integer, Integer>> indexForAllCentroids = new HashMap<String, HashMap<Integer, Integer>>();
		File alignmentFilePath = new File(outputDir + File.separator + alignmentFile);
		File readFileFilePath = new File(outputDir + File.separator + FileName);

		if (alignmentFilePath.exists() && readFileFilePath.exists())
		{

			List<AlignmentParser> myAlignments = AlignmentParser.getListOfAlignment(alignmentFilePath.getAbsolutePath());

			List<FastaSequenceParser> myReads = FastaSequenceParser.readFastaFile(readFileFilePath.getAbsolutePath());

			List<String> seqWithNoAlignment = flipFileParser(FileName,outputDir);

			if (myAlignments.size() != myReads.size())
			{

				myReads = getReadBasedOnAlignments(myAlignments, myReads);

				MyLogger.log(Level.INFO,
						"Number of alignments are not equal to number of centroids, only read with alignments was used",outputDir);
			}

			for (int x = 0; x < myAlignments.size(); x++)
			{

				String seqNameInAlignment = myAlignments.get(x).getNameofSeq();
				String alignment = myAlignments.get(x).getAlignment();

				String seqNameInRead = myReads.get(x).getHeader();
				String read = myReads.get(x).getSequence();

				if (!seqNameInAlignment.equals(seqNameInRead))
				{

					throw new Exception("Not the same sequences for reads (centroids) and alignments");

				}

				if (getAlignmentLength(alignment) != read.length())
				{

					MyLogger.log(Level.INFO, "alignment length is not identical to read length:" + seqNameInAlignment,outputDir);
				}

				if (seqWithNoAlignment == null || !seqWithNoAlignment.contains(seqNameInAlignment) && getAlignmentLength(alignment) == read.length())
				{

					HashMap<Integer, Integer> indexForOneCentroid = getIndex(alignment, read);
					indexForAllCentroids.put(read, indexForOneCentroid);
				}
			}

		}

		return indexForAllCentroids;
	}
	
	public static List<FastaSequenceParser> getReadBasedOnAlignments(List<AlignmentParser> alignments,
			List<FastaSequenceParser> reads)
	{

		HashMap<String, String> mapOfAlignments = convertListOFAlignmentToHashmap(alignments);
		List<FastaSequenceParser> newListOfReads = new ArrayList<>();

		for (FastaSequenceParser fs : reads)
		{

			if (mapOfAlignments.containsKey(fs.getHeader()))
			{
				newListOfReads.add(fs);
			}
		}
		return newListOfReads;

	}
	
	public static HashMap<String, String> convertListOFAlignmentToHashmap(List<AlignmentParser> alignments)
	{

		HashMap<String, String> mapOfAlignments = new HashMap<>();

		for (AlignmentParser alignment : alignments)
		{

			mapOfAlignments.put(alignment.getNameofSeq(), alignment.getNameofSeq());
		}
		return mapOfAlignments;
	}
	
	public static HashMap<Integer, Integer> getIndex(String alignment, String read) throws Exception
	{
		HashMap<Integer, Integer> myMap = new HashMap<Integer, Integer>();

		int indexInRead = 0;

		for (int x = 0; x < alignment.length(); x++)
		{
			char base = alignment.charAt(x);

			if (base != '.' && base != '-')
			{

				if (indexInRead < read.length())

				{
						myMap.put(indexInRead, x);
						indexInRead++;
					} else
					{
						break;
					}
				}
			}

		return myMap;
	}
	
	public static int getAlignmentLength(String alignment)
	{

		int count = 0;
		for (int x = 0; x < alignment.length(); x++)
		{
			char base = alignment.charAt(x);
			if (base != '.' && base != '-')
				count++;
		}
		return count;
	}
	
	
	public static FindMismatches extendMismatches(FindMismatches fm,
			HashMap<String, HashMap<Integer, Integer>> indexMap,
			HashMap<String, SilvaMutationPercentageParser> silvaMap) throws Exception
	{

		List<Integer> indexSilvaForMismatch = new ArrayList<>();
		List<String> permessiveInSilva = new ArrayList<>();

		List<Integer> indexForMismatch = fm.getIndex();
		List<Character> queryMismatch = fm.getsnpQ();

		Integer indexOfMismatch = indexForMismatch.get(0);
		Character snp = queryMismatch.get(0);

		Integer indexInSilva = indexMap.get(fm.getSubject()).get(indexOfMismatch);
		indexSilvaForMismatch.add(indexInSilva);

		SilvaMutationPercentageParser percentages = silvaMap.get(indexInSilva.toString());

		if (snp == 'A')
			permessiveInSilva.add(percentages.getA());

		else if (snp == 'C')
			permessiveInSilva.add(percentages.getC());

		else if (snp == 'G')
			permessiveInSilva.add(percentages.getG());

		else if (snp == 'T')
			permessiveInSilva.add(percentages.getT());

		else if (snp == 'N')
			permessiveInSilva.add(percentages.getN());

		else if (snp == '-')
			permessiveInSilva.add(percentages.getGap());

		else
			throw new Exception("The misMatch does not exist in Silva database");

		FindMismatches newFM = new FindMismatches(fm.getSubject(), fm.getQuery(), fm.getIndex(), fm.getNum(),
				fm.getsnpQ(), fm.getsnpS(), fm.getAbundance(), indexSilvaForMismatch, permessiveInSilva);

		return newFM;
	}
	
	
	public static HashMap<Holder, List<FindMismatches>> getSilvaIndexForMismatches(
			HashMap<Holder, List<FindMismatches>> cluster, HashMap<String, HashMap<Integer, Integer>> indexMap)
			throws Exception
	{

		HashMap<String, SilvaMutationPercentageParser> silvaMap = SilvaMutationPercentageParser
				.readSilvaPermutationPercentage(
						ConfigReader.getSilvaMutationRateDir() + File.separator + Constants.SILVAMUTATIONRATE);

		HashMap<Holder, List<FindMismatches>> newMapForCluster = new HashMap<Holder, List<FindMismatches>>();


			for (Holder centroid : cluster.keySet())
				
				
			{
				

				if (indexMap.containsKey(centroid.getSeq()))
				{

					
					
					List<FindMismatches> members = cluster.get(centroid);

					List<FindMismatches> newListForMembers = new ArrayList<>();

					for (FindMismatches eachMember : members)
					{

						newListForMembers.add(extendMismatches(eachMember, indexMap, silvaMap));
					}
					
					newMapForCluster.put(centroid, newListForMembers);
				}
			}
		
		return newMapForCluster;

	}
	
	
	public static void writeClusterTable(HashMap<Holder, List<FindMismatches>> cluster, String fileName,String outputDir)
			throws Exception
	{

			BufferedWriter writer = new BufferedWriter(
					new FileWriter(new File(outputDir + File.separator + fileName)));

			Integer clusterNum = 0;

			writer.write("Cluster" + "\t" + "Sequence" + "\t" + "NumMismatch" + "\t" + "SubjectSNP" + "\t" + "QuerySNP"
					+ "\t" + "Abundance" + "\t" + "Ratio" + "\t" + "Index" + "\t" + "SilvaIndex" + "\t" + "Permessive"
					+ "\n");

			for (Holder centroid : cluster.keySet())
			{

				clusterNum++;
				String c = "C" + clusterNum;

				writer.write(c + "\t" + centroid.getSeq() + "\t" + "NA" + "\t" + "NA" + "\t" + "NA" + "\t"
						+ centroid.getNum() + "\t" + "NA" + "\t" + 0 + "\t" + "NA" + "\t" + 25 + "\n");

				List<FindMismatches> members = cluster.get(centroid);

				for (FindMismatches eachMember : members)
				{

					writer.write(clusterNum + "\t" + eachMember.getQuery() + "\t" + eachMember.getNum() + "\t"
							+ eachMember.getsnpS().get(0) + "\t" + eachMember.getsnpQ().get(0) + "\t"
							+ eachMember.getAbundance() + "\t"
							+ eachMember.getIndex().get(0) + "\t" + eachMember.getIndexSilva().get(0) + "\t"
							+ eachMember.getPermessivePercentage().get(0) + "\n");

				}
			}

			MyLogger.log(Level.INFO, "Total number of centroids in: " + fileName + "  " + clusterNum,outputDir);
			writer.flush();
			writer.close();

		
	}
	
	
	public static class AbundancePermission implements Comparable<AbundancePermission>
	 {
		
		private final int abundace;
		private final double permission;
		
		@Override
		public int compareTo( AbundancePermission ap)
		{
			return this.abundace - ap.abundace;
		}
		
		public AbundancePermission(int abundace, double permission) {
			this.abundace = abundace;
			this.permission = permission;
		}
		
		public int getAbundance()
		{
			return abundace;
		}

		public double getPermission()
		{
			return permission;
		}
		
	}
	
	
	public static List<Integer> getAbundancesOfMismatches (HashMap<Holder,List<FindMismatches>> cluster){
		
		List<Integer> abundances = new ArrayList<>();
		
		for (Holder h : cluster.keySet()) {
			
			List<FindMismatches> members = cluster.get(h);
			
			for (FindMismatches member: members) {
				 abundances.add(member.getAbundance());
			}
			
		}
		return abundances;
	}
  public static List<Double> getPermissionsOfMismatches (HashMap<Holder,List<FindMismatches>> cluster){
		
		List<Double> permissions = new ArrayList<>();
		
		for (Holder h : cluster.keySet()) {
			
			List<FindMismatches> members = cluster.get(h);
			
			for (FindMismatches member: members) {
				permissions.add(Double.parseDouble(member.getPermessivePercentage().get(0)));
			}
			
		}
		return permissions;
	}

  public static List <AbundancePermission> getListOfAbundancePermission (List<Integer> abundances,List<Double> permissions){
	
	List<AbundancePermission> myList = new ArrayList <>();
	
	for (int x=0; x<abundances.size();x++) {
		
		AbundancePermission instance = new AbundancePermission (abundances.get(x),permissions.get(x));
		
		myList.add(instance);
		
	}
	Collections.sort(myList);
	return myList;
}
  
  
  public static List<Double> getARange(double start, double end, double interval){
	   
	   List<Double> range = new ArrayList<>();
	   
	   for (double x=start; x<=end; x=x+interval) {
		   range.add(x);
	   }
	   return range;
  }

  public static List<Double> getRedToTotalRatio(List<AbundancePermission> myList, List<Double> thresholds)
	{

		List<Double> listOfBlueToRed = new ArrayList<>();

		Double upperThreshold = thresholds.get(thresholds.size()-1)-thresholds.get(thresholds.size()-1) * 0.1;
		
		for (Double abundace : thresholds)
		{

			long total = 0;
			long red = 0;

			for (AbundancePermission ap : myList)
			{

				if (Math.log10(ap.getAbundance()) >= abundace)
				{
                  total =  total + ap.getAbundance();
					
					if (ap.getPermission() > 1.0 | (ap.getPermission() <= 1.0) & Math.log10(ap.getAbundance())>upperThreshold)
						
						red=red + ap.getAbundance();

				}
			}

			listOfBlueToRed.add((double) red / (double) total);
		}

		return listOfBlueToRed;

	}
  
  
  
  public static void writeRatios(List<Double> redToTotalRatioList,
			List<Double> thresholds,String fileName,String outputDir) throws Exception
	{

		BufferedWriter writer = new BufferedWriter(
				new FileWriter(new File(outputDir + File.separator + fileName)));

		writer.write("Thresholds" + "\t" + "Ratio" + "\n");

		for (int x = 0; x < redToTotalRatioList.size(); x++)
		{

			writer.write(thresholds.get(x) + "\t" + redToTotalRatioList.get(x) + "\n");

		}

		writer.flush();
		writer.close();

	}
	
  public static int getIndexOfRedToTotalRatio(List<Double> redToTotalRatioList, Double userSelectedRatio)
	{

		int index = 0;
		for (int x = 0; x < redToTotalRatioList.size(); x++)
		{

			if (redToTotalRatioList.get(x) >= userSelectedRatio)
			{

				index = x;
				break;

			} else
			{
				index = x;
			}

		}
		System.out.println(
				"Index at which the ratio is qual or greater than the selectedUserRatio is : "
						+ index);
		return index;

	}
  
  
  public static double getThreshold(List<Double> redToTotalRatioList,Double userSelectedRatio ,List<Double> thresholds,String outputDir) throws Exception
	{

		int index = getIndexOfRedToTotalRatio(redToTotalRatioList,userSelectedRatio);
		Double t = thresholds.get(index);
		MyLogger.log(Level.INFO, "Threshold is: " + t+"; Antilog: "+Math.pow(10, t), outputDir);
		return Math.pow(10, t);

	}
  
  
 

public static List<Holder> getUniqueSequence(HashMap<Holder, List<FindMismatches>> cluster, double threshold,String outputDir)
		throws Exception
{
	List<Holder> setOfUniqueSequence = new ArrayList<Holder>();
    System.out.println("Threshold is "+ threshold);
	

		for (Holder s : cluster.keySet())
		{
			if (s.getNum() > threshold)
				setOfUniqueSequence.add(s);
			List<FindMismatches> members = cluster.get(s);
			for (FindMismatches eachMember : members)
			{

				if (eachMember.getAbundance() > threshold)
				{

					setOfUniqueSequence.add(new Holder(eachMember.getQuery(), eachMember.getAbundance()));

				}

			}

		}
		Collections.sort(setOfUniqueSequence);



	MyLogger.log(Level.INFO, "Number of unique sequences: " + setOfUniqueSequence.size(),outputDir);
	return setOfUniqueSequence;

}
	
}