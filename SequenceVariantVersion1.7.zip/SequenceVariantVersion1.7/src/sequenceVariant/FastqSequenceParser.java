package sequenceVariant;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.logging.Level;
import utils.Constants;
import utils.MyLogger;

/**
 * This class parses fastq files into files that include unique sequence
 * variants and their abundances with decreasing order.
 * 
 * @author Farnaz Fouladi
 *
 */

public class FastqSequenceParser implements Comparable<FastqSequenceParser>
{

	private String sequence;
	private String header;

	public FastqSequenceParser(String header, String sequence)
	{
		this.sequence = sequence;
		this.header = header;
	}

	public int compareTo(FastqSequenceParser seq)
	{
		return this.getSequence().length() - seq.getSequence().length();
	}

	@Override

	public String toString()
	{
		return this.header + "\n" + this.sequence;

	}

	public String getSequence()
	{
		return sequence;
	}

	public String getHeader()
	{
		return header;
	}

	/**
	 * This method parses fastq files.
	 * 
	 * @param fastqFile sequence file (fastq)
	 * @return list of FastqSequenceParser objects. Objects are composed of headers
	 *         and sequences.
	 * @throws Exception if file is not found or a sequence does not exist after a
	 *                   header.
	 */

	public static List<FastqSequenceParser> readFastqFile(File fastqFile) throws Exception

	{
		List<FastqSequenceParser> list = new ArrayList<FastqSequenceParser>();
		BufferedReader reader = new BufferedReader(new FileReader(fastqFile));

		for (String nextline = reader.readLine(); nextline != null; nextline = reader.readLine())

		{

			if (nextline.startsWith("@") && nextline.length() < 100)
			{
				String sequence = reader.readLine();
				if (sequence == null || sequence.startsWith("@") || sequence.startsWith("+"))
				{
					reader.close();
					throw new Exception("No sequence after @sequenceFileName");
				}

				list.add(new FastqSequenceParser(nextline, sequence));

			}

		}
		reader.close();
		return list;

	}

	/**
	 * This method creates a Map from a fastq file.
	 * 
	 * @param input Fastq file
	 * @return a Map with keys as unique sequence variant and values as the
	 *         abundance of corresponding sequence variants.
	 * @throws Exception if file is not found or a sequence does not exist after a
	 *                   header when runs {@link#readFastqFile(File fastqFile)}.
	 */
	public static Map<String, Integer> getMap(File input) throws Exception
	{
		List<FastqSequenceParser> fastqList = readFastqFile(input);

		Map<String, Integer> hm = new HashMap<String, Integer>();

		for (FastqSequenceParser sequence : fastqList)
		{
			String seq = sequence.getSequence();
			Integer value = hm.get(seq);
			if (value == null)
				value = 0;
			value++;
			hm.put(seq, value);

		}

		return hm;
	}

	/**
	 * This class holds the sequence and its abundance. Holder objects can be
	 * compared based on the abundance of sequences.
	 * 
	 * @author Farnaz Fouladi
	 *
	 */
	public static class Holder implements Comparable<Holder>
	{

		private final String sequence;
		private final int numOfSeq;

		@Override
		public int compareTo(Holder o)
		{
			return o.numOfSeq - this.numOfSeq;
		}

		public String getSeq()
		{
			return sequence;
		}

		public int getNum()
		{
			return numOfSeq;
		}

		public Holder(String sequence, int numOfSeq)
		{
			this.sequence = sequence;
			this.numOfSeq = numOfSeq;
		}
	}

	/**
	 * This method writes all the unique sequence variants in a fastq file with
	 * their abundances in a decreasing order into a new file.
	 * 
	 * @param input     fastq file
	 * @param output    file to be written
	 * @param outputDir path to the main output directory
	 * @throws Exception if a file is not found or a sequence does not exist after a
	 *                   header in the fastq file when runs
	 *                   {@link#getMap(File input)}.
	 */

	public static void writeUniqueSV(File input, File output, String outputDir) throws Exception
	{
		int sum = 0;

		BufferedWriter writer = new BufferedWriter(new FileWriter(output));

		Map<String, Integer> myMap = getMap(input);

		List<Holder> listofSeuences = new ArrayList<Holder>();

		for (String key : myMap.keySet())
		{
			listofSeuences.add(new Holder(key, myMap.get(key)));
		}
		Collections.sort(listofSeuences);

		writer.write("Sequence" + "\t" + "Number of Sequences" + "\n");
		for (Holder h : listofSeuences)
		{
			writer.write(h.sequence + "\t" + h.numOfSeq + "\n");
			sum += h.numOfSeq;
		}

		MyLogger.log(Level.INFO, input.getName() + " has " + sum + " sequences", outputDir);

		writer.flush();
		writer.close();

	}

	/**
	 * This method parses all the fastq files into files in the
	 * {@value utils.Constants#PARSEDFILES} directory.
	 * 
	 * @param inputDir  directory path to the fastq files
	 * @param outputDir path to the main output directory
	 * @throws Exception if a file is not found or a sequence does not exist after a
	 *                   header in the fastq file when runs
	 *                   {@link#writeUniqueSV(File input, File output,String outputDir)}.
	 */

	public static void parseAllFiles(String inputDir, String outputDir) throws Exception
	{

		File inputDirectory = new File(inputDir);
		File outputDirectory = new File(outputDir);
		if (!outputDirectory.exists())
			outputDirectory.mkdirs();

		File parsedFileDirectory = new File(outputDir + File.separator + Constants.PARSEDFILES);

		if (!parsedFileDirectory.exists())
		{
			parsedFileDirectory.mkdirs();

			String[] files = inputDirectory.list();
			for (String s : files)
			{
				if (s.endsWith("fastq"))
				{
					File fastqFile = new File(inputDir + File.separator + s);
					StringTokenizer s1 = new StringTokenizer(s, ".");
					writeUniqueSV(fastqFile, new File(parsedFileDirectory.getAbsolutePath() + File.separator + "Parsed"
							+ s1.nextToken() + ".txt"), outputDir);
				}
			}

		}

	}

}
