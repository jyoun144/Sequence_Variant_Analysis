package sequenceVariant;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * This class is composed of subject sequence, query sequence, list of mismatch
 * indices, number of mismatches, list of mismatches in the subject, list of
 * mismatches in the query, query abundance, ratio of query abundance to subject
 * abundance, list of corresponding mismatch indices in the Silva database, list
 * of percentages of permessiveness for the mismatches (rate of mismatches
 * observed in the database). ParentMismatches are equal if they have the same
 * query.
 * 
 * @author Farnaz Fouladi
 *
 */

public class ParentMismatches
{

	private String subject;
	private String query;
	private List<Integer> index;
	private Integer num;
	private List<Character> snpQ;
	private List<Character> snpS;
	private Integer abundance;
	private List<String> permessivePercentage;

	/**
	 * A ParentMismatches object is constructed using the following parameters:
	 * 
	 * @param subject   subject sequence
	 * @param query     query sequence
	 * @param index     list of indices for mismatches
	 * @param num       number of mismatches
	 * @param snpQ      list of mismatched bases in the query sequence
	 * @param snpS      list of mismatched bases in the subject sequence
	 * @param abundance query abundance
	 */

	public ParentMismatches(String subject, String query, List<Integer> index, Integer num, List<Character> snpQ,
			List<Character> snpS, Integer abundance, List<String> permessivePercentage)
	{
		this.subject = subject;
		this.query = query;
		this.index = index;
		this.num = num;
		this.snpQ = snpQ;
		this.snpS = snpS;
		this.abundance = abundance;
		this.permessivePercentage = permessivePercentage;

	}

	public String getSubject()
	{
		return subject;
	}

	public String getQuery()
	{
		return query;
	}

	public List<Integer> getIndex()
	{
		return index;
	}

	public Integer getNum()
	{
		return num;
	}

	public List<Character> getsnpQ()
	{
		return snpQ;
	}

	public List<Character> getsnpS()
	{
		return snpS;
	}

	public Integer getAbundance()
	{
		return abundance;
	}

	public List<String> getPermessivePercentage()
	{
		return permessivePercentage;
	}

	@Override
	public boolean equals(Object obj)
	{

		ParentMismatches other = (ParentMismatches) obj;

		return other.getQuery().equals(this.getQuery());
	}

	@Override
	public int hashCode()
	{

		return query.hashCode();
	}

	public static String findPermessiveness(char n, SilvaMutationPercentageParser silvaParser) throws Exception
	{

		String permessiveness;

		if (n == 'A')
			permessiveness = silvaParser.getA();
		else if (n == 'C')
			permessiveness = silvaParser.getC();
		else if (n == 'G')
			permessiveness = silvaParser.getG();
		else if (n == 'T')
			permessiveness = silvaParser.getT();
		else if (n == '-')
			permessiveness = silvaParser.getGap();
		else if (n == 'N')
			permessiveness = silvaParser.getN();
		else
			throw new Exception("Error in Silva Parser");

		return permessiveness;

	}

	/**
	 * This method compares subject and query sequences and creates a
	 * ParentMismatches object.
	 * 
	 * @param subject a Holder containing a subject sequence and its abundance.
	 * @param query   a Holder containing a query sequence and its abundance.
	 * @see sequenceVariant.FastqSequenceParser.Holder
	 * @return ParentMismatches object
	 * @throws Exception if query and subject do not have the same length.
	 */

	public static ParentMismatches getMismatches(String subject, String subjectAlignment, String query,
			String queryAlignment, Integer gueryAbundance, HashMap<String, SilvaMutationPercentageParser> silvaMap)
			throws Exception
	{

		if (subjectAlignment.length() != queryAlignment.length())
		{
			throw new Exception("Sequence lengths for subject and query[Parent] are not identical");
		}

		int mismatch = 0;

		List<Integer> index = new ArrayList<Integer>();

		List<Character> snpS = new ArrayList<Character>();

		List<Character> snpQ = new ArrayList<Character>();

		List<String> permessivePercentage = new ArrayList<String>();

		for (Integer x = 0; x < subjectAlignment.length(); x++)
		{

			if (subjectAlignment.charAt(x) != '.' && queryAlignment.charAt(x) != '.'
					&& subjectAlignment.charAt(x) != queryAlignment.charAt(x))
			{

				index.add(x);
				mismatch++;
				snpS.add(subjectAlignment.charAt(x));
				snpQ.add(queryAlignment.charAt(x));
				SilvaMutationPercentageParser silvaParser = silvaMap.get(x.toString());
				permessivePercentage.add(findPermessiveness(queryAlignment.charAt(x), silvaParser));

			}

		}
		return new ParentMismatches(subject, query, index, mismatch, snpQ, snpS, gueryAbundance, permessivePercentage);
	}

}
