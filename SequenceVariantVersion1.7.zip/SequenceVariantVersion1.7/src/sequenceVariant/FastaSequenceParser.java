package sequenceVariant;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/**
 * This class parses a fasta sequence file.
 * 
 * @author Farnaz Fouladi
 */

public class FastaSequenceParser implements Comparable<FastaSequenceParser>
{
	private String sequence;
	private String header;

	/**
	 * This constructs FastaSequenceParser objects composed of header and sequence.
	 * @param header sequence header
	 * @param sequence sequence
	 */
	
	
	public FastaSequenceParser(String header, String sequence)
	{
		this.sequence = sequence;
		this.header = header;
	}

	public int compareTo(FastaSequenceParser seq)
	{
		return this.getHeader().compareTo(seq.getHeader());
	}

	@Override

	public String toString()
	{
		return this.header + "\n" + this.sequence;

	}

	public String getSequence()
	{
		return sequence;
	}

	public String getHeader()
	{
		return header;
	}

	/**
	 * This method parses fasta sequence file.
	 * 
	 * @param fastaFile file path
	 * @return list of FastaSequenceParser ordered by header name.
	 * @throws Exception if file is not found or if sequence does not exist after a
	 *                   header in the fasta file.
	 */

	public static List<FastaSequenceParser> readFastaFile(String fastaFile) throws Exception

	{
		List<FastaSequenceParser> list = new ArrayList<FastaSequenceParser>();
		BufferedReader reader = new BufferedReader(new FileReader(new File(fastaFile)));

		for (String nextline = reader.readLine(); nextline != null; nextline = reader.readLine())

		{

			if (nextline.startsWith(">") && nextline.length() < 100)
			{
				String sequence = reader.readLine();
				if (sequence == null || sequence.startsWith(">") || sequence.startsWith("+"))
				{
					reader.close();
					throw new Exception("No sequence after >SequenceName");
				}

				list.add(new FastaSequenceParser(nextline.substring(1, nextline.length()), sequence));

			}

		}
		reader.close();
		//Collections.sort(list);
		return list;

	}
	
	
	
	public static HashMap<String, String> readFastaFileAndGetMap(String fastaFile) throws Exception

	{
		HashMap<String, String> list = new HashMap<String, String>();
		BufferedReader reader = new BufferedReader(new FileReader(new File(fastaFile)));

		for (String nextline = reader.readLine(); nextline != null; nextline = reader.readLine())

		{

			if (nextline.startsWith(">") && nextline.length() < 100)
			{
				String sequence = reader.readLine();
				if (sequence == null || sequence.startsWith(">") || sequence.startsWith("+"))
				{
					reader.close();
					throw new Exception("No sequence after >SequenceName");
				}

				list.put(nextline.substring(1, nextline.length()), sequence);

			}

		}
		reader.close();
		//Collections.sort(list);
		return list;

	}
	
	public static HashMap<String, String> convertListOFFastaSequencesToHashmap(List<FastaSequenceParser> sequences)
	{

		HashMap<String, String> mapOfSequences = new HashMap<>();

		for (FastaSequenceParser sequence : sequences)
		{

			mapOfSequences.put(sequence.getHeader(), sequence.getSequence());
		}
		return mapOfSequences;
	}
}
