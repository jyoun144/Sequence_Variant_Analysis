package sequenceVariant;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.logging.Level;

import sequenceVariant.FastqSequenceParser.Holder;
import utils.ConfigReader;
import utils.Constants;
import utils.MyLogger;
import utils.ProcessWrapper;

/**
 * This class is composed of multiple static methods and does the followings:
 * <ol>
 * <li>Pools all the sequences from all the parsed files.
 * <li>Forms clusters of one mismatches. Cluster formation starts with the most
 * abundant sequence.
 * <li>Aligns the centroids of all clusters to the Silva alignment and for each
 * locus in the centroid sequence finds the corresponding Silva index in the
 * alignment. For each one-off variant of the clusters, allele frequency (
 * frequency of the mismatch in the database) is determined
 * <li>A threshold is determined based on on the fraction of one-off variants
 * with a specified allele frequency
 * <li>All the unique sequences below threshold are discarded and the sequences
 * above the threshold are kept.
 * </ol>
 * 
 * 
 * @author Farnaz Fouladi
 *
 */

public class PooledSamples

{

	/**
	 * This method provides a list of all parsed files by
	 * {@link sequenceVariant.FastqSequenceParser}.
	 * 
	 * @param outputDir path to the main directory.
	 * @return list of all parsed files.
	 */

	public static List<String> getAListOfParsedFiles(String outputDir)
	{

		List<String> listOfParsedFiles = new ArrayList<>();
		File parsedFileDirectory = new File(outputDir + File.separator + Constants.PARSEDFILES);
		String[] listOfAllFiles = parsedFileDirectory.list();

		for (String file : listOfAllFiles)
			listOfParsedFiles.add(file);

		return listOfParsedFiles;

	}

	/**
	 * This method parse all the files into a HashMap. Singletons are removed.
	 * 
	 * @see #getHashMapFromParsedFile(File parsedFile,String outputDir)
	 * @param files     list of files parsed by
	 *                  {@link sequenceVariant.FastqSequenceParser}
	 * @param outputDir path to the main output directory
	 * @return a HashMap with samples as keys and HashMaps of unique sequences
	 *         (keys) and their abundances (values) as values for each sample.
	 * @throws Exception if a file is not found.
	 */

	public static HashMap<String, HashMap<String, Integer>> readFiles(List<String> files, String outputDir,
			Boolean reverse) throws Exception
	{

		HashMap<String, HashMap<String, Integer>> outerMap = new HashMap<>();

		for (String s : files)
		{
			System.out.println(s);

			if (s.endsWith("txt") && s.startsWith("Parsed"))
			{
				File parsedFile = new File(outputDir + File.separator + Constants.PARSEDFILES + File.separator + s);
				HashMap<String, Integer> innerMap = getHashMapFromParsedFile(parsedFile, outputDir, reverse);
				outerMap.put(s, innerMap);
			}
		}

		return outerMap;
	}

	public static Boolean readHasN(String read)
	{

		Boolean n = false;

		String[] bases = read.split("");
		Set<String> set = new HashSet<>(Arrays.asList(bases));
		if (set.contains("N"))
			n = true;
		return n;

	}

	/**
	 * This method parses one file into a HashMap. Singletons are removed.
	 * 
	 * @param parsedFile file parsed by {@link sequenceVariant.FastqSequenceParser}
	 * @param outputDir  path to the main output directory
	 * @return a HashMap of unique sequences (keys) and their abundances (values)
	 *         (values) in the parsedFile.
	 * @throws Exception if the file is not found or the parsedFile has not been
	 *                   parsed correctly.
	 */
	public static HashMap<String, Integer> getHashMapFromParsedFile(File parsedFile, String outputDir, Boolean reverse)
			throws Exception
	{
		Integer numSingletons = 0;
		Integer numSVwithN = 0;
		Integer abundanceOfSVsWithN = 0;

		HashMap<String, Integer> mapForParsedFile = new HashMap<>();

		BufferedReader reader = new BufferedReader(new FileReader(parsedFile));

		for (String nextline = reader.readLine(); nextline != null; nextline = reader.readLine())
		{
			if (!nextline.startsWith("Sequence"))
			{
				String seq = nextline.substring(0, nextline.indexOf("\t"));
				String numSeq = nextline.substring(nextline.indexOf("\t") + 1, nextline.length());

				if (!numSeq.equals("1"))

				{
					if (mapForParsedFile.containsKey(seq))
					{
						reader.close();
						throw new Exception("Duplicate Sequence in the parsedFile.\n" + parsedFile
								+ "has not been parsed correctly.");

					}

					if (!readHasN(seq))
					{

						if (reverse)
							seq = reverseTranscribe(seq);

						mapForParsedFile.put(seq, Integer.parseInt(numSeq));

					} else
						numSVwithN++;
					abundanceOfSVsWithN = abundanceOfSVsWithN + Integer.parseInt(numSeq);

				} else
				{
					numSingletons++;
				}
			}

		}
		reader.close();
		MyLogger.log(Level.INFO, "Number of singletons in " + parsedFile.getName() + " are " + numSingletons,
				outputDir);

		MyLogger.log(Level.INFO, "Number of sequence variants with N in " + parsedFile.getName() + " is " + numSVwithN
				+ " and their total abundances are " + abundanceOfSVsWithN, outputDir);
		return mapForParsedFile;
	}

	/**
	 * This method pools all the sequences from all samples.
	 * 
	 * @param mapOfSamples a HashMap with samples as keys and HashMaps of unique
	 *                     sequences and their abundances as values returned by
	 *                     {@link #readFiles}.
	 * @return a HashMap with unique sequences (from all samples) as keys and their
	 *         abundances as values
	 */

	public static HashMap<String, Integer> totalAbundanceOfSV(HashMap<String, HashMap<String, Integer>> mapOfSamples)

	{

		HashMap<String, Integer> abundanceMap = new HashMap<String, Integer>();

		for (String sample : mapOfSamples.keySet())
		{

			HashMap<String, Integer> innerMap = mapOfSamples.get(sample);

			for (String sv : innerMap.keySet())
			{

				Integer numSeq = innerMap.get(sv);

				if (abundanceMap.containsKey(sv))
				{
					numSeq = numSeq + abundanceMap.get(sv);
				}

				abundanceMap.put(sv, numSeq);

			}
		}
		return abundanceMap;
	}

	/**
	 * This method first calls {@link totalAbundanceOfSV} to pool all the sequences
	 * from all samples, then it generates a list of holders (each holder is
	 * composed of a unique sequence with its pooled abundance
	 * {@link sequenceVariant.FastqSequenceParser.Holder}). The list is in a
	 * decreasing order.
	 * 
	 * @param mapOfSamples a HashMap with samples as keys and HashMaps of unique
	 *                     sequences and their abundances as values returned by
	 *                     {@link #readFiles}.
	 * @return list of holders ordered by abundances of unique sequences
	 */

	public static List<Holder> totalAbundanceOfSVwithOrder(HashMap<String, HashMap<String, Integer>> mapOfSamples)

	{
		List<Holder> listofSeuences = new ArrayList<Holder>();
		HashMap<String, Integer> abundanceMap = totalAbundanceOfSV(mapOfSamples);
		for (String sequence : abundanceMap.keySet())
		{
			listofSeuences.add(new Holder(sequence, abundanceMap.get(sequence)));
		}
		Collections.sort(listofSeuences);

		return listofSeuences;
	}

	public static LinkedHashMap<String, Holder1> convertListToLinkedHashMap(List<Holder> listOfSequences)
	{
		LinkedHashMap<String, Holder1> mapOfSequences = new LinkedHashMap<String, Holder1>();

		for (Holder h : listOfSequences)
		{

			mapOfSequences.put(h.getSeq(), new Holder1(h.getNum()));
		}

		return mapOfSequences;

	}

	/**
	 * This method forms one mismatch clusters.
	 * 
	 * @param mapOfSequences map of unique pooled sequences keys are sequences and
	 *                       values is the abundance in the form of Holder1
	 *                       {@link sequenceVariant.PooledSamples.Holder1}
	 * @param outputDir      path to the main output directory
	 * @return a LinkedHashMap with centroids (in the form of Holder
	 *         {@link sequenceVariant.FastqSequenceParser.Holder}) as keys and list
	 *         of the one-off variants in the form of FindMismatches objects
	 *         {@link sequenceVariant.FindMismatches#FindMismatches}.
	 * @see sequenceVariant.FindMismatches#getMismatches
	 * @throws Exception if an error occurs in generating a log file or if sequences
	 *                   do not have the same length.
	 */
	public static LinkedHashMap<Holder, List<FindMismatches>> findCluster(LinkedHashMap<String, Holder1> mapOfSequences,
			String outputDir) throws Exception
	{

		LinkedHashMap<Holder, List<FindMismatches>> parentsToChildren = new LinkedHashMap<Holder, List<FindMismatches>>();

		for (Iterator<String> i = mapOfSequences.keySet().iterator(); i.hasNext();)
		{
			String aSeq = i.next();
			Holder1 parentHolder = mapOfSequences.get(aSeq);
			Integer parentAbundance = parentHolder.getNum();
			i.remove();

			if (!parentHolder.getIsUsed())
			{
				List<FindMismatches> innerList = new ArrayList<FindMismatches>();
				parentsToChildren.put(new Holder(aSeq, parentAbundance), innerList);

				for (int x = 0; x < aSeq.length(); x++)
				{
					for (char c : ACGT)
					{
						String mutatedString = getMutatedSeq(aSeq, x, c);

						if (!mutatedString.contentEquals(aSeq))
						{
							Holder1 childSeq = mapOfSequences.get(mutatedString);

							if (childSeq != null && !childSeq.getIsUsed())
							{
								childSeq.setAsUsed();
								Integer childAbundance = childSeq.getNum();
								List<Integer> index = new ArrayList<>();
								index.add(x);
								List<Character> snpQ = new ArrayList<>();
								snpQ.add(c);
								List<Character> snpS = new ArrayList<>();
								snpS.add(aSeq.charAt(x));
								FindMismatches ms = new FindMismatches(aSeq, mutatedString, index, 1, snpQ, snpS,
										childAbundance);

								innerList.add(ms);
							}
						}
					}
				}
			}

		}
		MyLogger.log(Level.INFO, "Number of total members of cluster: " + parentsToChildren.size(), outputDir);
		MyLogger.log(Level.INFO, "Number of total parents: " + parentsToChildren.size(), outputDir);

		return parentsToChildren;

	}

	private static String getMutatedSeq(String seq, int pos, char c)
	{
		StringBuffer buff = new StringBuffer();

		for (int x = 0; x < seq.length(); x++)
		{
			if (x == pos)
				buff.append(c);
			else
				buff.append(seq.charAt(x));
		}

		return buff.toString();
	}

	private static char[] ACGT =
	{ 'A', 'C', 'G', 'T' };

	public static class Holder1
	{
		private int counts;
		private boolean used = false;

		public Holder1(int counts)
		{
			this.counts = counts;
		}

		public int getNum()
		{
			return this.counts;
		}

		public boolean getIsUsed()
		{
			return this.used;
		}

		public void setAsUsed()
		{
			this.used = true;
		}
	}

	/**
	 * This method calculate sum of the all abundances of unique sequences in all
	 * samples excluding singletons
	 * 
	 * @param listofSeuences pooled sequences in the form of a list of holders
	 *                       {@link sequenceVariant.FastqSequenceParser.Holder}
	 * @param ouputDir       path to the main output directory
	 * @return total abundance of all sequences except for singletons in samples
	 * @throws Exception If an error occurs in log file
	 */

	public static long getTotalAbundance(List<Holder> listofSeuences, String ouputDir) throws Exception
	{
		long abundance = 0;
		for (Holder h : listofSeuences)
		{
			abundance = abundance + h.getNum();
		}

		MyLogger.log(Level.INFO, "Total abundance of all sequences after removing singletons:" + abundance, ouputDir);
		return abundance;
	}

	/**
	 * This method generates a reverse complement of a sequence
	 * 
	 * @param read
	 * @return reverse complement
	 * @throws Exception
	 */

	public static String reverseTranscribe(String read) throws Exception
	{
		StringBuffer buff = new StringBuffer();

		for (int x = read.length() - 1; x >= 0; x--)
		{
			char c = read.charAt(x);

			if (c == 'A')
				buff.append('T');
			else if (c == 'T')
				buff.append('A');
			else if (c == 'C')
				buff.append('G');
			else if (c == 'G')
				buff.append('C');
			else if (c == 'N')
				buff.append('N');
			else
				throw new Exception("Error in complementary reverse. Check your reads");
		}

		return buff.toString();
	}

	/**
	 * This method calculated relative abundance for each unique sequence
	 * 
	 * @see #getTotalAbundance
	 * @param listofSeuences pooled sequences in the form of a list of holders
	 *                       {@link sequenceVariant.FastqSequenceParser.Holder}
	 * @param ouputDir       path to the main output directory
	 * @return list of relative abundances
	 * @throws Exception If an error occurs in log file
	 */

	public static List<Double> getRelativeAbundance(List<Holder> listofSeuences, String ouputDir) throws Exception
	{

		long totalAbundance = getTotalAbundance(listofSeuences, ouputDir);
		List<Double> relativeAbundaces = new ArrayList<>();

		for (Holder h : listofSeuences)
		{
			relativeAbundaces.add(((double) h.getNum() / (double) totalAbundance));
		}

		return relativeAbundaces;
	}

	/**
	 * This method checks if the HashMap containing one-mismatch clusters exists.
	 * 
	 * @param map a HashMap with centroids (in the form of Holder
	 *            {@link sequenceVariant.FastqSequenceParser.Holder}) as keys and
	 *            list of the one-off variants in the form of FindMismatches objects
	 *            ({@link sequenceVariant.FindMismatches#FindMismatches}) as values.
	 * @return true if the HashMap is not empty.
	 */

	public static Boolean doesClusterExist(HashMap<Holder, List<FindMismatches>> map)
	{

		Boolean clusterExit = true;
		if (map.isEmpty())
			clusterExit = false;
		return clusterExit;
	}

	/**
	 * This method writes a fasta file including all the centroids of one-mismatch
	 * clusters.
	 * 
	 * @param mapOfCluster a HashMap with centroids (in the form of Holder
	 *                     {@link sequenceVariant.FastqSequenceParser.Holder}) as
	 *                     keys and list of the one-off variants in the form of
	 *                     FindMismatches objects
	 *                     ({@link sequenceVariant.FindMismatches#FindMismatches})
	 *                     as values.
	 * @param fileName     the name of the file to be written
	 * @param outputDir    path to the main output directory
	 * @throws IOException I/O Exception
	 */

	public static void writeCentroids(LinkedHashMap<Holder, List<FindMismatches>> mapOfCluster, String fileName,
			String outputDir) throws IOException
	{

		if (doesClusterExist(mapOfCluster))
		{

			BufferedWriter writer = new BufferedWriter(new FileWriter(new File(outputDir + File.separator + fileName)));
			BufferedWriter writer1 = new BufferedWriter(
					new FileWriter(new File(outputDir + File.separator + "CentroidAbundance.txt")));
			writer1.write("Name\tSequence\tAbundance\n");

			int numCentroid = 0;
			for (Holder h : mapOfCluster.keySet())
			{
				numCentroid++;
				writer.write(">centroid" + numCentroid + "\n" + h.getSeq() + "\n");
				writer1.write("centroid" + numCentroid + "\t" + h.getSeq() + "\t" + h.getNum() + "\n");
			}
			writer.flush();
			writer.close();
			writer1.flush();
			writer1.close();
		}
	}

	/**
	 * This method writes sequences of centroids and members of all the clusters
	 * into a fasta file {@value #utils.Constants#ONEMISMATCHCLUSTERFILENAME}.
	 * 
	 * @param mapOfCluster a HashMap with centroids (in the form of Holder
	 *                     {@link sequenceVariant.FastqSequenceParser.Holder}) as
	 *                     keys and list of the one-off variants in the form of
	 *                     FindMismatches objects
	 *                     ({@link sequenceVariant.FindMismatches#FindMismatches})
	 *                     as values.
	 * @param outputDir    path to the main output directory
	 * @throws IOException
	 */

	public static void writeCluster(LinkedHashMap<Holder, List<FindMismatches>> mapOfCluster, String outputDir)
			throws IOException

	{

		if (doesClusterExist(mapOfCluster))
		{

			BufferedWriter writer = new BufferedWriter(
					new FileWriter(new File(outputDir + File.separator + Constants.ONEMISMATCHCLUSTERFILENAME)));

			int centroidNum = 0;

			for (Holder centroid : mapOfCluster.keySet())
			{
				centroidNum++;
				writer.write(">centroid" + centroidNum + "\n" + centroid.getSeq() + "\n");

				List<FindMismatches> members = mapOfCluster.get(centroid);

				int memberNum = 0;

				if (!members.isEmpty())
				{
					for (FindMismatches eachMember : members)
					{
						memberNum++;
						writer.write(">member" + memberNum + "_centroid" + centroidNum + "\n");
						writer.write(eachMember.getQuery() + "\n");

					}
				}

			}
			writer.close();
		}
	}

	/**
	 * This method runs align.seqs within Mothur. All the centroids of one-mismatch
	 * clusters are aligned to the Silva alignment
	 * {@link utils.Constants#SILVAALIGNMENT}
	 * 
	 * @param clusterExit checks if the HashMap of containg one-mismatch clusters
	 *                    exists
	 * @param fileName    the name of fasta file containing centroid sequences
	 * @param outputDir   path to the main output directory
	 * @throws Exception if the properties file or the name of a property
	 *                   (MOTHUR_DIR) is not found or if an error occurs during
	 *                   running Mothur.
	 */

	public static void runMother(Boolean clusterExit, String fileName, String outputDir) throws Exception
	{

		File filePath = new File(outputDir + File.separator + fileName);

		if (clusterExit)
		{

			String[] a = new String[2];
			a[0] = ConfigReader.getMothurDir() + File.separator + "mothur";
			a[1] = "#set.dir(output=" + outputDir + ");" + "align.seqs(candidate=" + filePath.getAbsolutePath()
					+ ", template=" + ConfigReader.getSilvaAlignmentDir() + File.separator + Constants.SILVAALIGNMENT
					+ ")";
			ProcessWrapper p = new ProcessWrapper(a);
		}
	}

	/**
	 * This method looks for a file with the extension ".flip.accnos" in the output
	 * directory. This file contains the names of centroids in the readFile that
	 * were not aligned to the Silva database or if their complementary reads
	 * produced a better alignment. This method calls
	 * {@link sequenceVariant.AlignmentParser#getSeqwithNoAlignment} and generates a
	 * list of sequence names in the .flip.accnos file.
	 * 
	 * @param readFile  the name of the fasta file containing centroid sequences
	 * @param outputDir path to the main output directory
	 * @return list of sequence names in the .flip.accnos file
	 * @throws Exception if the file is not found
	 */

	public static List<String> flipFileParser(String readFile, String outputDir) throws Exception
	{

		StringTokenizer str = new StringTokenizer(readFile, ".");
		String flipFile = str.nextToken() + ".flip.accnos";

		List<String> seqWithNoAlignment = new ArrayList<String>();

		File outputDirectory = new File(outputDir);
		String[] files = outputDirectory.list();

		for (String file : files)
		{

			if (file.endsWith(flipFile))
			{

				seqWithNoAlignment = AlignmentParser.getSeqwithNoAlignment(outputDir + File.separator + file);

			}
		}

		MyLogger.log(Level.INFO, "Number of centroids that did not produce alignments: " + seqWithNoAlignment.size()
				+ " Check " + flipFile, outputDir);

		return seqWithNoAlignment;
	}

	public static HashMap<String, String> convertListOFSequenceToHashmap(List<FastaSequenceParser> reads)
	{

		HashMap<String, String> mapOfSequences = new HashMap<>();

		for (FastaSequenceParser fs : reads)
		{

			mapOfSequences.put(fs.getHeader(), fs.getSequence());
		}
		return mapOfSequences;
	}

	/**
	 * This method finds the Silva alignment index for each corresponding locus in
	 * the centroid sequence.
	 * 
	 * @param fastaFile   the name of fasta file containing centroid sequences
	 * @param clusterExit checks if the HashMap of one-mismatch clusters exist
	 * @param outputDir   path to the main output directory
	 * @return a HashMap with centroid sequences as keys and HashMaps of centroid
	 *         indices and corresponding Silva alignment indices as values.
	 * @throws Exception if a file is not found or if a sequence and its alignment
	 *                   are not matched.
	 */

	public static LinkedHashMap<String, HashMap<Integer, Integer>> getIndexforAlignmentandRead(String fastaFile,
			String alignmentFile, HashMap<String, String> mapOfSequences, Boolean clusterExit, String outputDir)
			throws Exception
	{

		LinkedHashMap<String, HashMap<Integer, Integer>> indexForAllCentroids = new LinkedHashMap<String, HashMap<Integer, Integer>>();

		List<String> seqWithNoAlignment = flipFileParser(fastaFile, outputDir);

		FastaSequenceOneAtATime fsoatAlignment = new FastaSequenceOneAtATime(
				new File(outputDir + File.separator + alignmentFile));

		for (FastaSequence fs = fsoatAlignment.getNextSequence(); fs != null; fs = fsoatAlignment.getNextSequence())
		{
			String alignmentName = fs.getHeader().substring(1, fs.getHeader().length());

			String alignment = fs.getSequence();
			String read = mapOfSequences.get(alignmentName);

			int numberOfBasesInAlignment = getAlignmentLength(alignment);

			if (!seqWithNoAlignment.contains(alignmentName))
			{
				if (numberOfBasesInAlignment == read.length())
				{
					HashMap<Integer, Integer> indexForOneCentroid = getIndex(alignment, read);
					indexForAllCentroids.put(read, indexForOneCentroid);
				} else
				{
					MyLogger.log(Level.INFO, alignmentName + " alignment length is not identical to read length",
							outputDir);

				}

			}
		}

		fsoatAlignment.close();
		return indexForAllCentroids;
	}

	/**
	 * This method determines the Silva alignment index for each locus in the
	 * sequence. This method is called only when the alignment length and sequence
	 * length is the same (No insertion or deletion).
	 * {@link #getIndexforAlignmentandRead}
	 * 
	 * @param alignment alignment
	 * @param read      sequence
	 * @return a HashMap with sequence indices as keys and corresponding Silva
	 *         alignment indices as values.
	 */

	public static HashMap<Integer, Integer> getIndex(String alignment, String read)
	{
		HashMap<Integer, Integer> myMap = new HashMap<Integer, Integer>();

		int indexInRead = 0;

		for (int x = 0; x < alignment.length(); x++)
		{
			char base = alignment.charAt(x);

			if (base != '.' && base != '-')
			{

				if (indexInRead < read.length())

				{
					myMap.put(indexInRead, x);
					indexInRead++;
				} else
				{
					break;
				}
			}

		}
		return myMap;
	}

	/**
	 * This method counts the number of bases in the alignment.
	 * 
	 * @param alignment
	 * @return number of bases in the alignment.
	 */

	public static int getAlignmentLength(String alignment)
	{

		int count = 0;
		for (int x = 0; x < alignment.length(); x++)
		{
			char base = alignment.charAt(x);
			if (base != '.' && base != '-')
				count++;
		}
		return count;
	}

	/**
	 * This method creates new FindMismatches objects
	 * ({@link sequenceVariant.FindMismatches}) which include the corresponding
	 * Silva alignment index and allele frequency for each one-off variant.
	 * <ol>
	 * <li>Based on a given FindMismatches, the mismatch and its index in the
	 * sequence is determined
	 * <li>Based on the indexMap, the corresponding Silva Alignment index for each
	 * one-off variant is determined
	 * <li>Based on the silvaMap, allele frequency for each one-off variant is
	 * determined.
	 * <Li>New FindMismatches object is created. </lo>
	 * 
	 * @param fm       a FindMismatches object
	 *                 {@link sequenceVariant.FindMismatches#FindMismatches}.
	 * @param indexMap a HashMap with centroid sequences as keys and HashMaps of
	 *                 sequence indices and the corresponding Silva alignment
	 *                 indices as values returned by
	 *                 {@link #getIndexforAlignmentandRead}.
	 * @param silvaMap a HashMap with Silva alignment indices as keys and
	 *                 SilvaMutationPercentageParser as values
	 *                 {@link sequenceVariant.SilvaMutationPercentageParser}.
	 * @return new FindMismatches object
	 * @throws Exception if the mismatch is not valid
	 */

	public static FindMismatches extendMismatches(FindMismatches fm,
			LinkedHashMap<String, HashMap<Integer, Integer>> indexMap,
			HashMap<String, SilvaMutationPercentageParser> silvaMap) throws Exception
	{

		List<Integer> indexSilvaForMismatch = new ArrayList<>();
		List<String> permessiveInSilva = new ArrayList<>();

		List<Integer> indexForMismatch = fm.getIndex();
		List<Character> queryMismatch = fm.getsnpQ();

		Integer indexOfMismatch = indexForMismatch.get(0);
		Character snp = queryMismatch.get(0);

		Integer indexInSilva = indexMap.get(fm.getSubject()).get(indexOfMismatch);
		indexSilvaForMismatch.add(indexInSilva);

		SilvaMutationPercentageParser percentages = silvaMap.get(indexInSilva.toString());

		if (snp == 'A')
			permessiveInSilva.add(percentages.getA());

		else if (snp == 'C')
			permessiveInSilva.add(percentages.getC());

		else if (snp == 'G')
			permessiveInSilva.add(percentages.getG());

		else if (snp == 'T')
			permessiveInSilva.add(percentages.getT());

		else if (snp == 'N')
			permessiveInSilva.add(percentages.getN());

		else if (snp == '-')
			permessiveInSilva.add(percentages.getGap());

		else
			throw new Exception("The misMatch does not exist in Silva database");

		FindMismatches newFM = new FindMismatches(fm.getSubject(), fm.getQuery(), fm.getIndex(), fm.getNum(),
				fm.getsnpQ(), fm.getsnpS(), fm.getAbundance(), indexSilvaForMismatch, permessiveInSilva);

		return newFM;
	}

	/**
	 * 
	 * This method writes the indexMap returned by
	 * {@link #getIndexforAlignmentandRead} into a text file.
	 * 
	 * @param indexMap  a HashMap with centroid sequences as keys and HashMaps of
	 *                  indices and the corresponding Silva alignment indices as
	 *                  values returned by {@link #getIndexforAlignmentandRead}.
	 * @param outputDir path to the main output directory
	 * @throws IOException
	 */
	public static void writeIndexMap(LinkedHashMap<String, HashMap<Integer, Integer>> indexMap, String outputDir)
			throws IOException

	{

		BufferedWriter writer = new BufferedWriter(
				new FileWriter(new File(outputDir + File.separator + "indexMap.txt")));

		writer.write("Sequence" + "\t" + "readIndex" + "\t" + "alignmentIndex");
		for (String seq : indexMap.keySet())
		{
			HashMap<Integer, Integer> indices = indexMap.get(seq);
			for (Integer index : indices.keySet())
			{

				writer.write(seq + "\t" + index + "\t" + indices.get(index));

			}
		}

		writer.close();
	}

	/**
	 * This method creates new one-mismatch clusters by adding Silva alignment
	 * indices and allele frequency to FindMismatches objects
	 * {@link sequenceVariant.FindMismatches} using the method
	 * {@link #extendMismatches}. The new cluster include only centroids that
	 * generated alignment when aligned with Silva database,
	 * 
	 * @param cluster  a HashMap with centroids (in the form of Holder
	 *                 {@link sequenceVariant.FastqSequenceParser.Holder}) as keys
	 *                 and list of the one-off variants in the form of
	 *                 FindMismatches objects
	 *                 ({@link sequenceVariant.FindMismatches#FindMismatches}) as
	 *                 values.
	 * @param indexMap a HashMap with centroid sequences as keys and HashMaps of
	 *                 indices and the corresponding Silva alignment indices as
	 *                 values returned by {@link #getIndexforAlignmentandRead}.
	 * @return new cluster: a HashMap with centroids (in the form of Holder
	 *         {@link sequenceVariant.FastqSequenceParser.Holder}) as keys and list
	 *         of the one-off variants in the form of FindMismatches objects
	 *         ({@link sequenceVariant.FindMismatches}) as values.
	 * @throws Exception if the mismatches are not valid (Other than A, G, T, C) or
	 *                   if a file is not found.
	 */
	public static LinkedHashMap<Holder, List<FindMismatches>> getSilvaIndexForMismatches(
			HashMap<Holder, List<FindMismatches>> cluster, LinkedHashMap<String, HashMap<Integer, Integer>> indexMap)
			throws Exception
	{

		HashMap<String, SilvaMutationPercentageParser> silvaMap = SilvaMutationPercentageParser
				.readSilvaPermutationPercentage(
						ConfigReader.getSilvaMutationRateDir() + File.separator + Constants.SILVAMUTATIONRATE);

		LinkedHashMap<Holder, List<FindMismatches>> newMapForCluster = new LinkedHashMap<Holder, List<FindMismatches>>();

		if (doesClusterExist(cluster) && !indexMap.isEmpty())
		{

			for (Holder centroid : cluster.keySet())
			{

				if (indexMap.containsKey(centroid.getSeq()))
				{

					List<FindMismatches> members = cluster.get(centroid);

					List<FindMismatches> newListForMembers = new ArrayList<>();

					if (!members.isEmpty())
					{
						for (FindMismatches eachMember : members)
						{

							newListForMembers.add(extendMismatches(eachMember, indexMap, silvaMap));
						}
					}

					newMapForCluster.put(centroid, newListForMembers);
				}
			}
		}
		return newMapForCluster;

	}

	/**
	 * This method writes the one-mismatch clusters in to a text file.
	 * 
	 * @param cluster   a HashMap with centroids (in the form of Holder
	 *                  {@link sequenceVariant.FastqSequenceParser.Holder}) as keys
	 *                  and list of the one-off variants in the form of
	 *                  FindMismatches objects
	 *                  ({@link sequenceVariant.FindMismatches}) as values.
	 * @param fileName  name of the file to be written
	 * @param outputDir path to the main output directory
	 * @throws Exception
	 */

	public static void writeClusterTable(LinkedHashMap<Holder, List<FindMismatches>> cluster, String fileName,
			String outputDir) throws Exception
	{

		if (doesClusterExist(cluster))
		{

			BufferedWriter writer = new BufferedWriter(new FileWriter(new File(outputDir + File.separator + fileName)));

			Integer clusterNum = 0;

			writer.write("Cluster" + "\t" + "Sequence" + "\t" + "NumMismatch" + "\t" + "SubjectSNP" + "\t" + "QuerySNP"
					+ "\t" + "Abundance" + "\t" + "Index" + "\t" + "SilvaIndex" + "\t" + "Permessive" + "\n");

			for (Holder centroid : cluster.keySet())
			{

				clusterNum++;
				String c = "C" + clusterNum;

				writer.write(c + "\t" + centroid.getSeq() + "\t" + "NA" + "\t" + "NA" + "\t" + "NA" + "\t"
						+ centroid.getNum() + "\t" + 0 + "\t" + "NA" + "\t" + "NA" + "\n");

				List<FindMismatches> members = cluster.get(centroid);

				if (!members.isEmpty())
				{
					for (FindMismatches eachMember : members)
					{

						writer.write(clusterNum + "\t" + eachMember.getQuery() + "\t" + eachMember.getNum() + "\t"
								+ eachMember.getsnpS().get(0) + "\t" + eachMember.getsnpQ().get(0) + "\t"
								+ eachMember.getAbundance() + "\t" + eachMember.getIndex().get(0) + "\t"
								+ eachMember.getIndexSilva().get(0) + "\t" + eachMember.getPermessivePercentage().get(0)
								+ "\n");

					}
				}
			}

			MyLogger.log(Level.INFO, "Total number of centroids in " + fileName + "  " + clusterNum, outputDir);
			writer.flush();
			writer.close();

		}
	}

	/**
	 * This inner class is composed of the abundance of one-off variant and the
	 * allele frequency of the variant, AbundanceAlleleFreq objects are compared
	 * based on the abundances.
	 * 
	 * @author Farnaz Fouladi
	 *
	 */
	public static class AbundanceAlleleFreq implements Comparable<AbundanceAlleleFreq>
	{

		private final int abundace;
		private final double alleleFreq;

		@Override
		public int compareTo(AbundanceAlleleFreq ap)
		{
			return this.abundace - ap.abundace;
		}

		public AbundanceAlleleFreq(int abundace, double alleleFreq)
		{
			this.abundace = abundace;
			this.alleleFreq = alleleFreq;
		}

		public int getAbundance()
		{
			return abundace;
		}

		public double getAlleleFreq()
		{
			return alleleFreq;
		}

	}

	/**
	 * This method generate a list containing AbundanceAlleleFreq objects
	 * {@link AbundanceAlleleFreq}.
	 * 
	 * @param cluster a HashMap with centroids (in the form of Holder
	 *                {@link sequenceVariant.FastqSequenceParser.Holder}) as keys
	 *                and list of the one-off variants in the form of FindMismatches
	 *                objects ({@link sequenceVariant.FindMismatches}) as values.
	 * @return list of AbundanceAlleleFreq objects ordered in increasing abundance.
	 * @throws Exception
	 */

	public static List<AbundanceAlleleFreq> getListOfAbundanceAlleleFreqFromCluster(
			LinkedHashMap<ParentMismatches, List<FindMismatches>> cluster) throws Exception
	{

		List<AbundanceAlleleFreq> ap = new ArrayList<>();

		for (ParentMismatches p : cluster.keySet())
		{

			if (p.getNum() == 0) // Centroid is an exact match
				ap.add(new AbundanceAlleleFreq(p.getAbundance(), 100.0));

			else if (p.getNum() == 1) // Centroid has one mistmach
				ap.add(new AbundanceAlleleFreq(p.getAbundance(),
						Double.parseDouble(p.getPermessivePercentage().get(0))));
			else if (p.getNum() > 1)
				ap.add(new AbundanceAlleleFreq(p.getAbundance(), 0));
			else
				throw new Exception("parents have no mismatch");

			List<FindMismatches> members = cluster.get(p);

			if (!members.isEmpty())
			{
				for (FindMismatches member : members)
				{
					ap.add(new AbundanceAlleleFreq(member.getAbundance(),
							Double.parseDouble(member.getPermessivePercentage().get(0))));
				}
			}

		}
		Collections.sort(ap);
		return ap;
	}

	/**
	 * This method creates a list of all allele frequency from AbundanceAlleleFreq
	 * objects {@link AbundanceAlleleFreq}
	 * 
	 * @param listOfAps list of AbundanceAlleleFreq objects
	 * @return list of Allele frequency of one-off variants
	 */

	public static List<Double> getAlleleFreqOfMismatches(List<AbundanceAlleleFreq> listOfAps)
	{

		List<Double> alleleFreq = new ArrayList<>();

		for (AbundanceAlleleFreq ap : listOfAps)
		{

			alleleFreq.add(ap.getAlleleFreq());
		}
		return alleleFreq;
	}

	/**
	 * This method creates a list of all abundances from AbundanceAlleleFreq objects
	 * {@link AbundanceAlleleFreq}
	 * 
	 * @param listOfAps list of AbundanceAlleleFreq objects
	 * @return list of abundances of one-off variants
	 */

	public static List<Integer> getAbundanceOfMismatches(List<AbundanceAlleleFreq> listOfAps)
	{

		List<Integer> abundances = new ArrayList<>();

		for (AbundanceAlleleFreq ap : listOfAps)
		{

			abundances.add(ap.getAbundance());
		}
		return abundances;
	}

	/**
	 * This method creates list of objects from a list of one-off variant abundances
	 * and a list of allele frequencies
	 * 
	 * @param abundances        list of abundances
	 * @param alleleFrequencies list of allele frequencies
	 * @return list of AbundanceAlleleFreq
	 */

	public static List<AbundanceAlleleFreq> getListOfAbundanceAlleleFreq(List<Integer> abundances,
			List<Double> alleleFreqquencies)
	{

		List<AbundanceAlleleFreq> myList = new ArrayList<>();

		for (int x = 0; x < abundances.size(); x++)
		{

			AbundanceAlleleFreq instance = new AbundanceAlleleFreq(abundances.get(x), alleleFreqquencies.get(x));

			myList.add(instance);

		}
		Collections.sort(myList);
		return myList;
	}

	/**
	 * This method creates a range of doubles.
	 * 
	 * @param start    Double at which the range starts.
	 * @param end      Double at which the range ends.
	 * @param interval intervals between doubles in the list.
	 * @return list of doubles within the range.
	 */

	public static List<Double> getARange(double start, double end, double interval)
	{

		List<Double> range = new ArrayList<>();

		for (double x = start; x <= end; x = x + interval)
		{
			range.add(x);
		}
		return range;
	}

	/**
	 * This method iterates through a range of potential thresholds and at each
	 * threshold computes the ratio of the one-off reads with abundances above the
	 * threshold and the specified allele frequency to all the one-off reads with
	 * abundances above the threshold.
	 * 
	 * @param myList     list of AbundanceAlleleFreq objects
	 *                   {@link AbundanceAlleleFreq}.
	 * @param thresholds a range of doubles.
	 * @return list of ratios
	 */

	public static List<Double> getAlleleFreqFraction(List<AbundanceAlleleFreq> myList, List<Double> thresholds,
			double alleleFrequency)
	{

		List<Double> listAlleleFreqFraction = new ArrayList<>();

		for (Double abundace : thresholds)
		{

			long total = 0;
			long alleleFreq = 0;

			for (AbundanceAlleleFreq ap : myList)
			{

				if (Math.log10(ap.getAbundance()) >= abundace)
				{
					total = total + ap.getAbundance();

					if (ap.getAlleleFreq() > alleleFrequency)

						alleleFreq = alleleFreq + ap.getAbundance();
				}
			}
			listAlleleFreqFraction.add((double) alleleFreq / (double) total);
		}
		return listAlleleFreqFraction;
	}

	public static List<Integer> getNumSVForEachThreshold(List<AbundanceAlleleFreq> myList, List<Double> thresholds)
	{

		List<Integer> numSVList = new ArrayList<>();

		for (Double abundace : thresholds)
		{

			Integer numSV = 0;

			for (AbundanceAlleleFreq ap : myList)
			{

				if (Math.log10(ap.getAbundance()) >= abundace)
				{
					numSV++;
				}

			}

			numSVList.add(numSV);
		}
		return numSVList;

	}

	/**
	 * This method writes the ratios obtained from {@link #getRedTotalRatio} at
	 * different thresholds into a text file.
	 * 
	 * @param redTotalRatioList list of ratios obtained from
	 *                          {@link #getRedTotalRatio}
	 * @param thresholds        range of thresholds obtained from {@link #getARange}
	 * @param outputDir         path to output directory
	 * @throws IOException
	 */

	public static void writeRatios(List<Double> listAlleleFreqFraction, List<Integer> numSVList,
			List<Double> thresholds, String outputDir) throws IOException
	{

		BufferedWriter writer = new BufferedWriter(
				new FileWriter(new File(outputDir + File.separator + Constants.RATIOFILENAME)));

		writer.write("Thresholds" + "\t" + "Number Of SVs" + "\t" + "Ratio" + "\n");

		for (int x = 0; x < listAlleleFreqFraction.size(); x++)
		{

			writer.write(thresholds.get(x) + "\t" + numSVList.get(x) + "\t" + listAlleleFreqFraction.get(x) + "\n");

		}

		writer.flush();
		writer.close();

	}

	/**
	 * This method finds an index in the list of ratios generated from
	 * {@link #getRedTotalRatio} that corresponds to the ratio selected by the user.
	 * 
	 * @param redTotalRatioList list of ratios obtained from
	 *                          {@link #getRedTotalRatio}
	 * @param userSelectedRatio the ratio selected by the user
	 * @return
	 */

	public static int getIndexOfalleleFreqFractionList(List<Double> alleleFreqFractionList, Double userSelectedRatio)
	{

		int index = 0;
		for (int x = 0; x < alleleFreqFractionList.size(); x++)
		{

			if (alleleFreqFractionList.get(x) >= userSelectedRatio)
			{

				index = x;
				break;

			} else
			{
				index = x;
			}

		}
		System.out.println("Index at which the ratio is qual or greater than the selectedUserRatio is : " + index);
		return index;

	}

	/**
	 * This method finds a filtering threshold based on the user selected fraction
	 * of one-off reads with having a specified allele frequency
	 * 
	 * @param alleleFreqFractionList list of ratios obtained from
	 *                          {@link #getRedTotalRatio}
	 * @param userSelectedRatio the ratio selected by the user
	 * @param thresholds        range of thresholds obtained from {@link #getARange}
	 * @param outputDir         path to the output directory
	 * @return
	 * @throws Exception
	 */

	public static double getThreshold(List<Double> alleleFreqFractionList, Double userSelectedRatio, List<Double> thresholds,
			String outputDir) throws Exception
	{

		int index = getIndexOfalleleFreqFractionList(alleleFreqFractionList, userSelectedRatio);
		Double t = thresholds.get(index);
		MyLogger.log(Level.INFO, "Threshold is: " + t + "; Antilog: " + Math.pow(10, t), outputDir);
		return Math.pow(10, t);

	}

	/**
	 * This method creates a list of unique sequence variants based on the abundance
	 * threshold and allele frequency
	 * 
	 * @param cluster         a HashMap with centroids (in the form of Holder
	 *                        {@link sequenceVariant.FastqSequenceParser.Holder}) as
	 *                        keys and list of the one-off variants in the form of
	 *                        FindMismatches objects
	 *                        ({@link sequenceVariant.FindMismatches}) as values.
	 * @param threshold       obtained from {@link #getThreshold}
	 * @param alleleFrequency user selected allele frequency
	 * @param outputDir       path to output directory
	 * @return
	 * @throws Exception
	 */

	public static List<Holder> getUniqueSequence(LinkedHashMap<Holder, List<FindMismatches>> cluster, double threshold,
			double alleleFrequency, String outputDir) throws Exception
	{
		List<Holder> setOfUniqueSequence = new ArrayList<Holder>();
		System.out.println("Threshold is " + threshold);

		if (doesClusterExist(cluster))
		{

			for (Holder s : cluster.keySet())
			{
				if (s.getNum() > threshold)
					setOfUniqueSequence.add(s);
				List<FindMismatches> members = cluster.get(s);
				for (FindMismatches eachMember : members)
				{

					if (eachMember.getAbundance() > threshold)
					{

						setOfUniqueSequence.add(new Holder(eachMember.getQuery(), eachMember.getAbundance()));

					}

				}

			}
			Collections.sort(setOfUniqueSequence);

		}

		MyLogger.log(Level.INFO, "Number of unique sequences is " + setOfUniqueSequence.size()
				+ " at Allele frequency of " + alleleFrequency, outputDir);
		return setOfUniqueSequence;

	}

	/**
	 * This method writes all the unique sequence variants into a fasta file after
	 * filtering.
	 * 
	 * @param listOfUniqueSequence list of sequences with abundances greater than
	 *                             the threshold. Sequences are part of the Holder
	 *                             objects
	 *                             {@link sequenceVariant.FastqSequenceParser.Holder}
	 * @param fileName             the name of the file to be written
	 * @param outputDir            the path to the output directory
	 * @throws IOException
	 */

	public static void writeUniqueSV(List<Holder> listOfUniqueSequence, String fileName, String outputDir)
			throws IOException

	{

		if (!listOfUniqueSequence.isEmpty())
		{
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File(outputDir + File.separator + fileName)));
			int svNum = 0;
			for (Holder h : listOfUniqueSequence)
			{
				svNum++;
				writer.write(">SV" + svNum + "\n" + h.getSeq() + "\n");
			}
			writer.close();
		}
	}
}