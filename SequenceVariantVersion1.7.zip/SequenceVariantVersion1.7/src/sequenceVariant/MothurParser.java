package sequenceVariant;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;

import utils.Constants;

public class MothurParser
{

	private final String query;
	private final String subject;
	private final String queryStart;
	private final String queryEnd;
	private final String subjectStart;
	private final String subjectEnd;
	private final String similarity;

	public String getQuery()
	{
		return query;
	}

	public String getSubject()
	{
		return subject;
	}

	public String getQueryStart()
	{
		return queryStart;
	}

	public String getQueryEnd()
	{
		return queryEnd;
	}
	
	public String getSubjectStart()
	{
		return subjectStart;
	}

	public String getSubjectEnd()
	{
		return subjectEnd;
	}
	public String getSimilarity()
	{
		return similarity;
	}


	public MothurParser(String propertiesOfAlignment)
	{

		String[] splits = propertiesOfAlignment.split("\t");
		this.query = splits[0];
		this.subject = splits[2];
		this.queryStart = splits[7];
		this.queryEnd = splits[8];
		this.subjectStart = splits[9];
		this.subjectEnd = splits[10];
        this.similarity = splits[15];
	}

	
	public static HashMap<String, MothurParser> reportParser(String outputDir) throws Exception
	{

		HashMap<String, MothurParser> myMap = new HashMap<String, MothurParser>();

		BufferedReader reader = new BufferedReader(new FileReader(new File(outputDir+File.separator+Constants.MOTHURREPORT)));

		for (String nextLine = reader.readLine(); nextLine != null; nextLine = reader.readLine())
		{

			if (!nextLine.startsWith("QueryName"))
			{

				MothurParser myInstance = new MothurParser(nextLine);

				if (myMap.containsKey(myInstance.query)) {
					
					reader.close();
					throw new Exception("Duplicate");
					
				}
					

				myMap.put(myInstance.query, myInstance);

			}
		}

		reader.close();
		return myMap;
	}

}
