package utils;

public class Constants
{
	public static final String PARSEDFILES = "ParsedFiles";
	public static final String ONEMISMATCHCENTROIDSFILENAME = "OneMismatchCentroids.fasta";
	public static final String ONEMISMATCHCENTROIDALIGNMENTFILENAME = "OneMismatchCentroids.align";
	public static final String MOTHURREPORT = "OneMismatchCentroids.align.report";
	public static final String ONEMISMATCHCLUSTERFILENAME = "OneMismatchCluster.txt";
	public static final String ONEMISMATCHCLUSTERTABLE = "TableOfClustersWithOneMismatch.txt";
	public static final Integer PERMUTATIONS = 1000;
	public static final Double INTERVALFORRANGE = 0.001;
	public static final Double MINRANGE = 0.1;
	public static final String RATIOFILENAME = "Ratios.txt";
	public static final String UNIQUESVCLUSTERONEMISMATCH = "UniqueSVClusterOneMismatch.fasta";
	public static final String SILVAMUTATIONRATE = "SilvaMutationPercentage.txt";
	public static final String SILVAALIGNMENT = "silva.nr_v132.align";
	public static final String TABLENAME = "SvTable.txt";
	public static final String NOTUNIQUESV = "NotUniqueSV.txt";
	public static final Double RELATIVEABUNDANCETHRESHOLD = 0.0;
}