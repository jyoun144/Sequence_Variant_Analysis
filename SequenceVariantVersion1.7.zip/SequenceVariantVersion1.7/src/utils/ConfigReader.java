package utils;

import java.io.InputStream;
import java.util.Properties;

public class ConfigReader
{
	public static final String PROPERTIES_FILE = "SequenceVariant.properties";

	private static ConfigReader configReader = null;
	private static Properties props = new Properties();

	public static final String TRUE = "TRUE";
	public static final String YES = "YES";

	public static final String MOTHUR_DIR = "MOTHUR_DIR";
	public static final String SEQUENCE_DIR = "SEQUENCE_DIR";
	public static final String DATABASE_DIR = "DATABASE_DIR";
	public static final String VERBOSE_CONSOLE = "VERBOSE_CONSOLE";
	public static final String OUTPUT_DIR = "OUTPUT_DIR";
	public static final String SILVAMUTATIONRATE_DIR = "SILVAMUTATIONRATE_DIR";
	public static final String SILVAALIGNMENT_DIR = "SILVAALIGNMENT_DIR";

	private ConfigReader() throws Exception
	{
		Object o = new Object();

		InputStream in = o.getClass().getClassLoader().getSystemResourceAsStream(PROPERTIES_FILE);

		if (in == null)
			throw new Exception("Error!  Could not find " + PROPERTIES_FILE + " anywhere on the current classpath");

		props = new Properties();
		props.load(in);

	}

	private static synchronized ConfigReader getConfigReader() throws Exception
	{
		if (configReader == null)
		{
			configReader = new ConfigReader();
		}

		return configReader;
	}

	private String getAProperty(String namedProperty) throws Exception
	{
		Object obj = props.get(namedProperty);

		if (obj == null)
			throw new Exception("Error!  Could not find " + namedProperty + " in " + PROPERTIES_FILE);

		return obj.toString();
	}

	private boolean isSetToTrue(String namedProperty)
	{
		Object obj = props.get(namedProperty);

		if (obj == null)
			return false;

		if (obj.toString().equalsIgnoreCase(TRUE) || obj.toString().equalsIgnoreCase(YES))
			return true;

		return false;
	}

	public static boolean isVerboseConsole() throws Exception
	{
		return getConfigReader().isSetToTrue(VERBOSE_CONSOLE);
	}

	public static String getMothurDir() throws Exception
	{
		return getConfigReader().getAProperty(MOTHUR_DIR);
	}

	public static String getSequenceDir() throws Exception
	{
		return getConfigReader().getAProperty(SEQUENCE_DIR);
	}

	public static String getDatabaseDir() throws Exception
	{
		return getConfigReader().getAProperty(DATABASE_DIR);
	}

	public static String getOutputDir() throws Exception
	{
		return getConfigReader().getAProperty(OUTPUT_DIR);
	}

	public static String getSilvaMutationRateDir() throws Exception
	{
		return getConfigReader().getAProperty(SILVAMUTATIONRATE_DIR);
	}

	public static String getSilvaAlignmentDir() throws Exception
	{
		return getConfigReader().getAProperty(SILVAALIGNMENT_DIR);
	}

}
