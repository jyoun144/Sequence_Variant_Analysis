package utils;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;


public class MyLogger
{

	private static Logger logger;
	private FileHandler fileHandler;
	private SimpleFormatter formatter;
	

	private MyLogger(String outputDir) throws SecurityException, IOException 
	{

		logger = Logger.getLogger(MyLogger.class.getName());
		fileHandler = new FileHandler(outputDir + File.separator + "logFile.log");
		formatter = new SimpleFormatter();
		fileHandler.setFormatter(formatter);
		logger.addHandler(fileHandler);

	}

	private static Logger getLogger(String outputDir) throws Exception
	{
		if (logger == null)
		{
			try
			{
				new MyLogger(outputDir);
			} catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		return logger;
	}

	public static void log(Level level, String msg,String outputDir) throws Exception 
	{
		getLogger(outputDir).log(level, msg);
	}

}
