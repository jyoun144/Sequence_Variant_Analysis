# SequenceVariantVersion1.7

SequenceVariant identifies true biological sequence variants from background noise. This pipeline estimates a filtering threshold
based on the fraction of reads that are required to match a database at a specifed allele frequency. This filtering threshold 
is used to segregate true biological sequences from sequencing errors. This pipeline is fast and easy to run. The dependies
include Java Decelopment Kit, Apache Ant, and Mothur software. Below are the instructions to start the application:


1. In the command line of your terminal type:

git clone https://github.com/FarnazFouladi/SequenceVariantVersion1.7.git

2. Install Apache Ant. Apache Ant is a Java library and command-line tool that help building software.
Instructions can be found at https://ant.apache.org/manual/install.html

3. Download silva.nr_v132.tgz and then extract the tar file:

wget https://mothur.s3.us-east-2.amazonaws.com/wiki/silva.nr_v132.tgz

tar -xzf silva.nr_v132.tgz


4. Find sequenceVariant.properties in the directory of SequenceVariantVersion1.7/src and then add the absolute path of silva.nr_v132.align to SILVAALIGNMENT_DIR in the sequenceVariant.properties. Note, only the absolute path of the directory containing silva.nr_v132.align should be added without including the file name (silva.nr_v132.align). For example:  

SILVAALIGNMENT_DIR=/Users/farnazfouladi/database/SilvaAlignment

5. Find SilvaMutationPercentage.txt located in the SequenceVariantVersion1.7/src directoty and add the absolute path of this file to SILVAMUTATIONRATE_DIR in the sequenceVariant.properties. Note, only the path should be added without including the file name. For example: 

SILVAMUTATIONRATE_DIR=/Users/farnazfouladi/SequenceVariantVersion1.7/src

6. Download one of an executable version of mothur from https://www.mothur.org/wiki/Download_mothur. Extract the file and add the path to the MOTHUR_DIR in the sequenceVariant.properties. For example:  

MOTHUR_DIR=/Users/farnazfouladi/mothur

7. From the directory of SequenceVariantVersion1.7 run ant to compile java class files.

8. To run the pipeline on your data, in the command line type:

java -cp pathTo/SequenceVariantVersion1.7/bin sequenceVariant.RunPipeline  PathToDirectoryOfSequenceFiles PathToOutputDirectory fraction alleleFrequency


Parameters:

-cp  the class path. 

sequenceVariant.RunPipeline  main method

PathToDirectoryOfSequenceFiles: This should be an absolute path and not a relative path. Also, in this versition of the pipeline input sequences should not be compressed and should be in fastq format.

PathToOutputDirectory. Note that output directory does not have to exist. The path should be absolute.

fraction: the fraction of reads that are required to match the databse at a specified allefrequence. The range is dependent on the dataset (refer to the manuscript) but usually is 1.0-0.8

allele frequency Options: 1, 5 , 10

An example:

java -cp /Users/farnazfouladi/SequenceVariantVersion1.7/bin sequenceVariant.RunPipeline /Users/farnazfouladi/Zymo /Users/farnazfouladi/Zymo_output 0.97 1 